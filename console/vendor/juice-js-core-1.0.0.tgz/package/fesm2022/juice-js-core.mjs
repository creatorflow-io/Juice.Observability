import * as i0 from '@angular/core';
import { InjectionToken, Injectable, NgModule, inject, Optional, ɵisPromise as _isPromise, createNgModule, Type, Directive, Inject } from '@angular/core';
import { firstValueFrom } from 'rxjs/internal/firstValueFrom';
import { Observable, isObservable, from, of, firstValueFrom as firstValueFrom$1, throwError, retry, timer, tap, catchError, finalize, shareReplay } from 'rxjs';
import { map, mergeMap } from 'rxjs/operators';
import { ROUTES } from '@angular/router';
import * as i1 from '@angular/material/dialog';
import { HttpContextToken, HttpContext, HttpErrorResponse, HttpResponse, HTTP_INTERCEPTORS } from '@angular/common/http';

const TENANT_RESOLVER = new InjectionToken('TENANT_RESOLVER');
class TenantResolverService {
    constructor() {
        this.priority = 0;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantResolverService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantResolverService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantResolverService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class ConfigResolver extends TenantResolverService {
    constructor(config) {
        super();
        this.config = config;
        this.priority = 99;
    }
    getTenantByIdentifier(identifier) {
        if (identifier === '') {
            return new Observable(subscriber => {
                subscriber.next({ identifier: '' });
                subscriber.complete();
            });
        }
        const tenant = this.config.find(tenant => tenant.identifier === identifier);
        if (tenant) {
            return new Observable(subscriber => {
                subscriber.next(tenant);
                subscriber.complete();
            });
        }
        return new Observable(subscriber => {
            subscriber.next(null);
            subscriber.complete();
        });
    }
}

class TenantModule {
    static forRoot(tenants = []) {
        return {
            ngModule: TenantModule,
            providers: [
                TenantService,
                {
                    provide: TENANT_RESOLVER,
                    useValue: new ConfigResolver(tenants),
                    multi: true
                },
                {
                    provide: TENANT_RESOLVER,
                    useClass: StorageResolver,
                    multi: true
                }
            ]
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.0.6", ngImport: i0, type: TenantModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantModule, decorators: [{
            type: NgModule,
            args: [{}]
        }] });

class StorageResolver extends TenantResolverService {
    static { this.CURRENT_TENANT = '_TENANT_'; }
    constructor() {
        super();
        this.priority = 100;
    }
    getTenantByIdentifier(identifier) {
        var currentTenant = localStorage.getItem(StorageResolver.CURRENT_TENANT);
        var tenantInfo = currentTenant ? JSON.parse(currentTenant) : null;
        if (tenantInfo && tenantInfo.identifier === identifier) {
            return new Observable(subscriber => {
                subscriber.next(tenantInfo);
                subscriber.complete();
            });
        }
        return new Observable(subscriber => {
            subscriber.next(null);
            subscriber.complete();
        });
    }
    saveTenant(tenant) {
        localStorage.setItem(StorageResolver.CURRENT_TENANT, JSON.stringify(tenant));
    }
    clearTenant() {
        localStorage.removeItem(StorageResolver.CURRENT_TENANT);
    }
    getCurrentTenant() {
        var currentTenant = localStorage.getItem(StorageResolver.CURRENT_TENANT);
        return currentTenant ? JSON.parse(currentTenant) : null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: StorageResolver, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: StorageResolver, providedIn: TenantModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: StorageResolver, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: TenantModule
                }]
        }], ctorParameters: () => [] });

class TenantService {
    constructor(storageResolver) {
        this.currentTenant = null;
        this.requestTenantIdentifier = null;
        this.resolvers = [];
        this.resolvers = inject(TENANT_RESOLVER, { optional: true }) ?? [];
        this.storageResolver = storageResolver;
        this.currentTenant = this.storageResolver?.getCurrentTenant();
    }
    async getTenantIdentifier() {
        return (await this.getTenantInfo())?.identifier;
    }
    async getTenantByIdentifier(identifier) {
        if (!this.resolvers) {
            return null;
        }
        for (const resolver of this.resolvers.sort((a, b) => b.priority - a.priority)) {
            // console.debug(`Resolving tenant ${identifier} by ${resolver.constructor.name}`);
            var tenant = await firstValueFrom(resolver.getTenantByIdentifier(identifier));
            if (tenant) {
                tenant.resolvedBy = resolver.constructor.name;
                console.debug(`Tenant ${tenant.identifier} resolved by ${tenant.resolvedBy}`);
                if (!(resolver instanceof StorageResolver) || tenant.identifier != this.currentTenant?.identifier) {
                    this.storageResolver?.saveTenant(tenant);
                    this.currentTenant = tenant;
                }
                return tenant;
            }
        }
        return null;
    }
    async getTenantInfo() {
        // :tenant/:module/:component
        var tenant = window.location.pathname.split('/')[1];
        this.requestTenantIdentifier = tenant;
        return (await this.getTenantByIdentifier(tenant))
            ?? this.storedTenant()
            ?? null;
    }
    storedTenant() {
        return this.storageResolver?.getCurrentTenant();
    }
    isMatched() {
        return this.currentTenant?.identifier == this.requestTenantIdentifier;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantService, deps: [{ token: StorageResolver, optional: true }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: StorageResolver, decorators: [{
                    type: Optional
                }] }] });

function wrapIntoObservable(value) {
    if (isObservable(value)) {
        return value;
    }
    if (_isPromise(value)) {
        // Use `Promise.resolve()` to wrap promise-like instances.
        // Required ie when a Resolver returns a AngularJS `$q` promise to correctly trigger the
        // change detection.
        return from(Promise.resolve(value));
    }
    return of(value);
}

async function loadChildren(menu, parentInjector, tenant) {
    if (menu.loaded) {
        menu.injectTenant(tenant);
        return;
    }
    // console.debug("loadChildren", menu.rawRouterLink);
    if (!hasChildren(menu)) {
        return;
    }
    await loadChildrenInternal(menu, parentInjector, tenant)
        .then(children => {
        if (children != null) {
            console.debug("loadedChildren", menu.rawRouterLink, children.map(c => c.rawRouterLink));
            menu.children = children;
            menu.injectTenant(tenant);
        }
        menu.loaded = true;
    });
}
async function loadChildrenInternal(menu, parentInjector, tenant) {
    var result = [];
    var children = await firstValueFrom$1(getChildren(menu, parentInjector, tenant));
    for (let child of children) {
        if (hasChildren(child)) {
            var sub = await loadChildrenInternal(child, parentInjector, tenant);
            if (sub.length > 0) {
                result = result.concat(sub);
            }
        }
        else {
            result.push(child);
        }
    }
    return result.map(child => {
        child.rawRouterLink = menu.replaceChildRouterLink && menu.rawRouterLink ?
            ('/' + menu.rawRouterLink.trimSlash() + '/' + child.rawRouterLink.trimSlash()).trimEndSlash()
            : '/' + child.rawRouterLink.trimSlash();
        return child;
    });
}
function hasChildren(menu) {
    return !((menu.children == null || menu.children.length == 0) && !menu.loadChildren);
}
function getChildren(menu, parentInjector, tenant) {
    if (menu.loadChildren) {
        return wrapIntoObservable(menu.loadChildren())
            .pipe(map(t => loadMenus(t, parentInjector)));
    }
    else {
        return of(menu.children.filter(m => filterMenu(m, parentInjector)));
    }
}
function loadMenus(menusOrModule, parentInjector) {
    if (Array.isArray(menusOrModule)) {
        return menusOrModule.map(menu => new MenuItem(menu));
    }
    const module = createNgModule(menusOrModule, parentInjector);
    const injector = module.injector;
    const menus = injector.get(MENUS, [], { optional: true, self: true }).flat();
    const routes = injector.get(ROUTES, [], { optional: true, self: true });
    var routeMenus = mapRouteMenu(routes);
    // console.debug("loadMenus", menus, routeMenus);
    return menus.map(menu => new MenuItem(menu)).concat(routeMenus)
        .filter(m => filterMenu(m, injector));
}
function filterMenu(menu, injector) {
    if (menu.canDisplay instanceof Boolean) {
        return menu.canDisplay;
    }
    const canDisplays = getCanDisplays(menu.canDisplay);
    return (canDisplays.length === 0 || canDisplays.every((c) => {
        if (c instanceof Type) {
            const service = injector.get(c);
            return service.canDisplay();
        }
        else if (c instanceof Function) {
            return c();
        }
        return true;
    }));
}
function getCanDisplays(canDisplay) {
    if (canDisplay instanceof Boolean) {
        return [];
    }
    return Array.isArray(canDisplay) ? canDisplay : [];
}
function mapRouteMenu(routes) {
    return routes
        .map(route => route.filter(isMenu).map(r => {
        if (!r.data) {
            r.data = {};
        }
        return MenuItem.fromRoute(r);
    })).flatMap(m => m.map(r => r));
}
function isMenu(route) {
    return route.data && (route.data['menuDisplay'] || route.data['menuWrapper']);
}

class MenuItem {
    constructor(menu) {
        this.id = "";
        this.label = "";
        this.routerLink = "";
        this.icon = "";
        this.order = 0;
        this.loaded = false;
        this.id = menu.id;
        this.label = menu.label;
        this.routerLink = menu.routerLink;
        this.icon = menu.icon;
        this.order = menu.order ?? 0;
        this.children = menu.children?.map(m => new MenuItem(m)) ?? [];
        this.loadChildren = menu.loadChildren;
        this.replaceChildRouterLink = menu.replaceChildRouterLink ?? true;
        this.loaded = false;
        this.rawRouterLink = menu.routerLink;
        this.canDisplay = menu.canDisplay ?? [];
    }
    static fromRoute(route) {
        var menu = new MenuItem({
            id: route.path ?? '',
            label: route.data['menuTitle'] ?? route.title ?? route.path ?? '',
            routerLink: route.path ?? '',
            icon: route.data['menuIcon'] ?? '',
            order: route.data['menuOrder'] ?? 0,
            children: route.children?.filter(isMenu).map(r => MenuItem.fromRoute(r)) ?? [],
            loadChildren: route.loadChildren,
            replaceChildRouterLink: true,
            canDisplay: route.data['menuDisplay']
        });
        return menu;
    }
    hasChildren() {
        return this.children.length > 0;
    }
    injectTenant(tenant) {
        this.children?.forEach(item => {
            if (item.hasChildren()) {
                item.injectTenant(tenant);
            }
            else {
                item.routerLink = item.rawRouterLink.injectTenant(tenant);
            }
        });
        this.routerLink = this.rawRouterLink.injectTenant(tenant);
    }
}
const MENUS = new InjectionToken('MENUS');

class MenuService {
    constructor(injector, tenantService) {
        this.injector = injector;
        this.tenantService = tenantService;
        this.routes = [];
        this.routes = inject(ROUTES, { optional: true }) ?? [];
    }
    getMenu() {
        var menus = this.injector.get(MENUS, [], { optional: true, self: true }).flat();
        var routeMenus = mapRouteMenu(this.routes);
        // console.debug("getMenu", menus, routeMenus, this.routes);
        return of(menus)
            .pipe(map(menus => menus.map(m => new MenuItem(m))), map(async (menus) => {
            var tenant = await this.tenantService.getTenantIdentifier();
            let menuItems = [];
            for (let menu of menus.concat(routeMenus)) {
                await loadChildren(menu, this.injector, tenant);
                menuItems.push(menu);
            }
            return menuItems;
        }), mergeMap(menus => menus), map(menus => menus.sort((a, b) => (a.order ?? 0) - (b.order ?? 0))));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: MenuService, deps: [{ token: i0.Injector }, { token: TenantService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: MenuService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: MenuService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i0.Injector }, { type: TenantService }] });

class MenuModule {
    /**
   * Creates and configures a module with all the menu providers.
   * Optionally sets up an application listener to perform an initial navigation.
   *
   * When registering the NgModule at the root, import as follows:
   *
   * ```
   * @NgModule({
   *   imports: [MenuModule.forRoot(MENUS)]
   * })
   * class MyNgModule {}
   * ```
   *
   * @param menus An array of `Route` objects that define the navigation paths for the application.
   * @return The new `NgModule`.
   *
   */
    static forRoot(menus) {
        return {
            ngModule: MenuModule,
            providers: [
                MenuService,
                {
                    provide: MENUS,
                    multi: true,
                    useValue: menus
                }
            ]
        };
    }
    /**
   * Creates a module with all the menus, without creating a new Router service.
   * When registering for submodules and lazy-loaded submodules, create the NgModule as follows:
   *
   * ```
   * @NgModule({
   *   imports: [MenuModule.forChild(MENUS)]
   * })
   * class MyNgModule {}
   * ```
   *
   * @param menus An array of `MenuItem` objects that define the navigation paths for the submodule.
   * @return The new NgModule.
   *
   */
    static forChild(menus) {
        return {
            ngModule: MenuModule,
            providers: [{ provide: MENUS, multi: true, useValue: menus }],
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: MenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.0.6", ngImport: i0, type: MenuModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: MenuModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: MenuModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [],
                    exports: []
                }]
        }] });

function loadChildrenRoutes(menusOrModule) {
    const module = createNgModule(menusOrModule.ngModule);
    const injector = module.injector;
    const menus = injector.get(ROUTES, [], { optional: true, self: true }).flat();
    return menus;
}

String.prototype.trimStartSlash = function () {
    return this.replace(/^[\/]+/, '');
};
String.prototype.trimEndSlash = function () {
    return this.replace(/[\/]+$/, '');
};
String.prototype.trimSlash = function () {
    return this.trimStartSlash().trimEndSlash();
};
String.prototype.injectTenant = function (tenant) {
    return '/' + this.replace(':tenant', tenant ?? '').trimStartSlash();
};

class AsyncDialog {
    constructor(matDialog) {
        this.matDialog = matDialog;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AsyncDialog, deps: [{ token: i1.MatDialog }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.0.6", type: AsyncDialog, isStandalone: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AsyncDialog, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i1.MatDialog }] });

/**
 * Operation identifier that groups all HTTP attempts belonging to one logical
 * state-changing operation. Requests carrying the same operation id reuse the
 * same `Idempotency-Key` (across double-clicks and retries); a `null` value
 * means the request is not opted into idempotency.
 */
const IDEMPOTENCY_OPERATION = new HttpContextToken(() => null);
/**
 * Optional client-side retry horizon (in milliseconds) that bounds how long a
 * key may be reused, mirroring the backend retention window. Past this age the
 * request is surfaced as an expired condition rather than silently treated as new.
 */
const IDEMPOTENCY_MAX_AGE_MS = new HttpContextToken(() => null);
/**
 * Build (or extend) an {@link HttpContext} that opts a request into idempotency
 * for the given logical operation.
 *
 * @example
 * this.http.post('/orders', body, { context: withIdempotency('create-order-42') });
 */
function withIdempotency(operationId, maxAgeMs, context = new HttpContext()) {
    context.set(IDEMPOTENCY_OPERATION, operationId);
    if (maxAgeMs != null) {
        context.set(IDEMPOTENCY_MAX_AGE_MS, maxAgeMs);
    }
    return context;
}

/**
 * Raised when the backend rejects a request because the same `Idempotency-Key`
 * was reused with a materially different payload (HTTP 422).
 */
class IdempotencyConflictError extends Error {
    constructor(operationId, message = 'Idempotency key conflict: the same key was reused with a different payload.') {
        super(message);
        this.operationId = operationId;
        this.name = 'IdempotencyConflictError';
    }
}
/**
 * Raised when an endpoint requires an `Idempotency-Key` but none was supplied
 * (HTTP 400). Should not occur in normal client flow because the interceptor
 * always attaches a key to opted-in requests.
 */
class IdempotencyKeyRequiredError extends Error {
    constructor(message = 'Idempotency-Key header is required for this request.') {
        super(message);
        this.name = 'IdempotencyKeyRequiredError';
    }
}
/**
 * Raised when a key has exceeded its client-side retry horizon and can no longer
 * be safely reused for the same operation.
 */
class IdempotencyExpiredError extends Error {
    constructor(operationId, message = 'Idempotency key expired; the operation can no longer be safely retried with the same key.') {
        super(message);
        this.operationId = operationId;
        this.name = 'IdempotencyExpiredError';
    }
}

/**
 * Classify an {@link HttpErrorResponse} against the backend idempotency contract
 * (see the Juice backend `011-idempotency-key-api` feature):
 * - `409` → operation is still in progress (retry after backoff)
 * - `422` → key reused with a different payload (conflict)
 * - `400` with an idempotency-key ProblemDetails title → key required
 * - anything else → not an idempotency signal
 */
function classifyError(error) {
    switch (error.status) {
        case 409:
            return 'in-progress';
        case 422:
            return 'conflict';
        case 400: {
            const title = (error.error && error.error.title) || '';
            return /idempotency[-\s]?key/i.test(title) ? 'required' : 'other';
        }
        default:
            return 'other';
    }
}

/**
 * Optional provider of a user-scoped identifier (e.g. the authenticated subject)
 * folded into the idempotency key scope so keys are never reused across a user
 * switch. Kept as a token so `@juice-js/core` does not depend on `@juice-js/auth`
 * (which would introduce a circular library dependency). Applications with auth
 * provide `{ provide: IDEMPOTENCY_USER_CONTEXT, useValue: () => oauth.getIdentityClaims()?.sub ?? null }`.
 */
const IDEMPOTENCY_USER_CONTEXT = new InjectionToken('IDEMPOTENCY_USER_CONTEXT');
/**
 * Generates, stores, and reuses a collision-resistant `Idempotency-Key` per
 * logical operation. The same operation id yields the same key across retries
 * and double-submits; distinct operations get distinct keys; and keys are scoped
 * to the current tenant/user so they never leak across a context switch.
 */
class IdempotencyKeyService {
    constructor(tenant, userContext) {
        this.tenant = tenant;
        this.userContext = userContext;
        this.entries = new Map();
    }
    currentScope() {
        const t = this.tenant?.currentTenant?.identifier ?? this.tenant?.requestTenantIdentifier ?? '';
        const u = this.userContext?.() ?? '';
        return `${t}|${u}`;
    }
    newKey() {
        if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
            return crypto.randomUUID();
        }
        // Fallback RFC4122-style generator for environments without crypto.randomUUID.
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
            const r = (Math.random() * 16) | 0;
            const v = c === 'x' ? r : (r & 0x3) | 0x8;
            return v.toString(16);
        });
    }
    /**
     * Return the existing key for this operation, or generate a new one. If the
     * current tenant/user scope differs from the stored entry, a fresh key is
     * generated (FR-010).
     */
    getKey(operationId) {
        const scope = this.currentScope();
        const existing = this.entries.get(operationId);
        if (existing && existing.scope === scope) {
            return existing.key;
        }
        const entry = { key: this.newKey(), scope, createdAt: Date.now(), inFlight: false };
        this.entries.set(operationId, entry);
        return entry.key;
    }
    /** Forget the key for a completed (or abandoned) operation. */
    release(operationId) {
        this.entries.delete(operationId);
    }
    /**
     * Whether the stored key for the operation has exceeded the given retry
     * horizon. Returns `false` when no horizon is set or no key exists yet.
     */
    isExpired(operationId, maxAgeMs) {
        if (maxAgeMs == null) {
            return false;
        }
        const entry = this.entries.get(operationId);
        if (!entry) {
            return false;
        }
        return Date.now() - entry.createdAt > maxAgeMs;
    }
    /**
     * UI-level double-submit guard (FR-009). Returns `false` if an operation is
     * already in flight, so callers can suppress a duplicate dispatch.
     */
    tryBeginInFlight(operationId) {
        const scope = this.currentScope();
        const entry = this.entries.get(operationId) ?? { key: this.newKey(), scope, createdAt: Date.now(), inFlight: false };
        if (entry.inFlight) {
            return false;
        }
        entry.inFlight = true;
        this.entries.set(operationId, entry);
        return true;
    }
    /** Clear the in-flight flag set by {@link tryBeginInFlight}. */
    endInFlight(operationId) {
        const entry = this.entries.get(operationId);
        if (entry) {
            entry.inFlight = false;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: IdempotencyKeyService, deps: [{ token: TenantService, optional: true }, { token: IDEMPOTENCY_USER_CONTEXT, optional: true }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: IdempotencyKeyService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: IdempotencyKeyService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: TenantService, decorators: [{
                    type: Optional
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [IDEMPOTENCY_USER_CONTEXT]
                }] }] });

/**
 * Attaches an `Idempotency-Key` header to opted-in state-changing requests and
 * interprets the backend idempotency responses:
 * - replayed success is passed through and the key released;
 * - `409` in-progress triggers a bounded backoff retry reusing the same key;
 * - `422` conflict and `400` required surface as typed errors without resubmission;
 * - keys past their retry horizon surface as an expired error.
 *
 * On top of the shared key, it de-duplicates concurrent dispatches of the same
 * operation (FR-009): while one attempt is in flight, a second subscription to
 * the same operation is coalesced onto the first in-flight response instead of
 * issuing a parallel request, so a double-click settles on a single outcome.
 *
 * Mirrors the `@juice-js/auth` `AuthInterceptor` idiom.
 */
class IdempotencyInterceptor {
    constructor(keys) {
        this.keys = keys;
        this.maxInProgressRetries = 3;
        this.baseBackoffMs = 500;
        /**
         * Shared, in-flight response streams keyed by operation id. Present only while
         * an operation is being sent; cleared when it settles (success or error).
         */
        this.inFlight = new Map();
    }
    isUnsafe(method) {
        const m = method.toUpperCase();
        return m === 'POST' || m === 'PUT' || m === 'PATCH' || m === 'DELETE';
    }
    intercept(req, next) {
        const operationId = req.context.get(IDEMPOTENCY_OPERATION);
        // Not opted in, or a safe/read-only request → pass through untouched (FR-004).
        if (!operationId || !this.isUnsafe(req.method)) {
            return next.handle(req);
        }
        const maxAgeMs = req.context.get(IDEMPOTENCY_MAX_AGE_MS);
        if (this.keys.isExpired(operationId, maxAgeMs)) {
            this.keys.release(operationId);
            return throwError(() => new IdempotencyExpiredError(operationId));
        }
        // FR-009: a duplicate dispatch while the operation is in flight rides the
        // existing response instead of firing a parallel request.
        const existing = this.inFlight.get(operationId);
        if (existing) {
            return existing;
        }
        const key = this.keys.getKey(operationId);
        const idempotentReq = req.clone({ headers: req.headers.set('Idempotency-Key', key) });
        const shared = next.handle(idempotentReq).pipe(retry({
            count: this.maxInProgressRetries,
            delay: (error, retryCount) => {
                // Only retry the in-progress signal; every other error propagates immediately.
                if (!(error instanceof HttpErrorResponse) || classifyError(error) !== 'in-progress') {
                    throw error;
                }
                return timer(this.baseBackoffMs * Math.pow(2, retryCount - 1));
            },
        }), tap((event) => {
            if (event instanceof HttpResponse) {
                this.keys.release(operationId);
            }
        }), catchError((error) => {
            if (error instanceof HttpErrorResponse) {
                switch (classifyError(error)) {
                    case 'conflict':
                        this.keys.release(operationId);
                        return throwError(() => new IdempotencyConflictError(operationId));
                    case 'required':
                        this.keys.release(operationId);
                        return throwError(() => new IdempotencyKeyRequiredError());
                    case 'in-progress':
                        // Retries exhausted while still in progress — surface the original error,
                        // keeping the key so a later manual retry can reuse it within retention.
                        return throwError(() => error);
                    default:
                        return throwError(() => error);
                }
            }
            return throwError(() => error);
        }), 
        // Drop the coalescing entry once the operation settles so the next dispatch
        // starts a fresh attempt. With refCount:false below this fires on terminal
        // success or error, not on a subscriber leaving mid-flight.
        finalize(() => this.inFlight.delete(operationId)), 
        // Multicast the single attempt to every coalesced subscriber; refCount:false
        // keeps the request running even if the initial subscriber unsubscribes.
        shareReplay({ bufferSize: 1, refCount: false }));
        this.inFlight.set(operationId, shared);
        return shared;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: IdempotencyInterceptor, deps: [{ token: IdempotencyKeyService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: IdempotencyInterceptor }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: IdempotencyInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: IdempotencyKeyService }] });

/**
 * Registers the {@link IdempotencyInterceptor} so opted-in state-changing
 * requests automatically carry an `Idempotency-Key` header.
 *
 * @example
 * imports: [IdempotencyModule]
 */
class IdempotencyModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: IdempotencyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.0.6", ngImport: i0, type: IdempotencyModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: IdempotencyModule, providers: [
            { provide: HTTP_INTERCEPTORS, useClass: IdempotencyInterceptor, multi: true },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: IdempotencyModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        { provide: HTTP_INTERCEPTORS, useClass: IdempotencyInterceptor, multi: true },
                    ],
                }]
        }] });

/*
 * Public API Surface of core
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AsyncDialog, IDEMPOTENCY_MAX_AGE_MS, IDEMPOTENCY_OPERATION, IDEMPOTENCY_USER_CONTEXT, IdempotencyConflictError, IdempotencyExpiredError, IdempotencyInterceptor, IdempotencyKeyRequiredError, IdempotencyKeyService, IdempotencyModule, MENUS, MenuItem, MenuModule, MenuService, TenantModule, TenantService, classifyError, loadChildrenRoutes, withIdempotency };
//# sourceMappingURL=juice-js-core.mjs.map
