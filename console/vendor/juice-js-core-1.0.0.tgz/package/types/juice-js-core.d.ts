import * as i0 from '@angular/core';
import { ModuleWithProviders, InjectionToken, Injector } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Observable as Observable$1 } from 'rxjs';
import { Route, Routes } from '@angular/router';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HttpContextToken, HttpContext, HttpErrorResponse, HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';

interface TenantInfo {
    identifier: string;
    name: string;
    description?: string;
    logo?: string;
    favicon?: string;
    theme?: string;
    resolvedBy?: string;
}

declare abstract class TenantResolverService {
    priority: number;
    abstract getTenantByIdentifier(identifier: string): Observable<TenantInfo | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TenantResolverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TenantResolverService>;
}

declare class StorageResolver extends TenantResolverService {
    static CURRENT_TENANT: string;
    priority: number;
    constructor();
    getTenantByIdentifier(identifier: string): Observable$1<TenantInfo | null>;
    saveTenant(tenant: TenantInfo): void;
    clearTenant(): void;
    getCurrentTenant(): TenantInfo | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<StorageResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StorageResolver>;
}

declare class TenantService {
    currentTenant: TenantInfo | null;
    requestTenantIdentifier: string | null;
    resolvers: TenantResolverService[];
    storageResolver: StorageResolver | undefined;
    constructor(storageResolver: StorageResolver);
    getTenantIdentifier(): Promise<string | undefined>;
    private getTenantByIdentifier;
    getTenantInfo(): Promise<TenantInfo | null>;
    storedTenant(): TenantInfo | null | undefined;
    isMatched(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<TenantService, [{ optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TenantService>;
}

declare class TenantModule {
    static forRoot(tenants?: TenantInfo[]): ModuleWithProviders<TenantModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TenantModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TenantModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TenantModule>;
}

declare class MenuItem {
    id: string;
    label: string;
    routerLink: string;
    rawRouterLink: string;
    icon: string;
    order: number;
    children: MenuItem[];
    loadChildren?: Function;
    replaceChildRouterLink: boolean;
    loaded: boolean;
    canDisplay: any[] | boolean;
    constructor(menu: Menu);
    static fromRoute(route: Route): MenuItem;
    hasChildren(): boolean;
    injectTenant(tenant: string | null | undefined): void;
}
interface Menu {
    id: string;
    label: string;
    routerLink: string;
    icon: string;
    order?: number;
    children?: Menus;
    loadChildren?: any;
    replaceChildRouterLink?: boolean;
    canDisplay?: any[] | boolean;
}
type Menus = Menu[];
declare const MENUS: InjectionToken<Menus[]>;
interface CanDisplay {
    canDisplay(): boolean;
}

declare class MenuService {
    private injector;
    private tenantService;
    routes: Route[][];
    constructor(injector: Injector, tenantService: TenantService);
    getMenu(): Observable$1<MenuItem[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MenuService>;
}

declare class MenuModule {
    /**
   * Creates and configures a module with all the menu providers.
   * Optionally sets up an application listener to perform an initial navigation.
   *
   * When registering the NgModule at the root, import as follows:
   *
   * ```
   * @NgModule({
   *   imports: [MenuModule.forRoot(MENUS)]
   * })
   * class MyNgModule {}
   * ```
   *
   * @param menus An array of `Route` objects that define the navigation paths for the application.
   * @return The new `NgModule`.
   *
   */
    static forRoot(menus: Menus): ModuleWithProviders<MenuModule>;
    /**
   * Creates a module with all the menus, without creating a new Router service.
   * When registering for submodules and lazy-loaded submodules, create the NgModule as follows:
   *
   * ```
   * @NgModule({
   *   imports: [MenuModule.forChild(MENUS)]
   * })
   * class MyNgModule {}
   * ```
   *
   * @param menus An array of `MenuItem` objects that define the navigation paths for the submodule.
   * @return The new NgModule.
   *
   */
    static forChild(menus: Menus): ModuleWithProviders<MenuModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MenuModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MenuModule>;
}

declare function loadChildrenRoutes(menusOrModule: ModuleWithProviders<any>): Routes;

declare global {
    interface String {
        trimStartSlash(): string;
        trimEndSlash(): string;
        trimSlash(): string;
        injectTenant(tenant: string | null | undefined): string;
    }
}

declare abstract class AsyncDialog<ComponentType, DataType, ReturnType = unknown> {
    protected matDialog: MatDialog;
    constructor(matDialog: MatDialog);
    abstract open(data: DataType): Promise<MatDialogRef<ComponentType, ReturnType>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsyncDialog<any, any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AsyncDialog<any, any, any>, never, never, {}, {}, never, never, true, never>;
}

/**
 * Operation identifier that groups all HTTP attempts belonging to one logical
 * state-changing operation. Requests carrying the same operation id reuse the
 * same `Idempotency-Key` (across double-clicks and retries); a `null` value
 * means the request is not opted into idempotency.
 */
declare const IDEMPOTENCY_OPERATION: HttpContextToken<string | null>;
/**
 * Optional client-side retry horizon (in milliseconds) that bounds how long a
 * key may be reused, mirroring the backend retention window. Past this age the
 * request is surfaced as an expired condition rather than silently treated as new.
 */
declare const IDEMPOTENCY_MAX_AGE_MS: HttpContextToken<number | null>;
/**
 * Build (or extend) an {@link HttpContext} that opts a request into idempotency
 * for the given logical operation.
 *
 * @example
 * this.http.post('/orders', body, { context: withIdempotency('create-order-42') });
 */
declare function withIdempotency(operationId: string, maxAgeMs?: number, context?: HttpContext): HttpContext;

/**
 * Raised when the backend rejects a request because the same `Idempotency-Key`
 * was reused with a materially different payload (HTTP 422).
 */
declare class IdempotencyConflictError extends Error {
    readonly operationId: string;
    constructor(operationId: string, message?: string);
}
/**
 * Raised when an endpoint requires an `Idempotency-Key` but none was supplied
 * (HTTP 400). Should not occur in normal client flow because the interceptor
 * always attaches a key to opted-in requests.
 */
declare class IdempotencyKeyRequiredError extends Error {
    constructor(message?: string);
}
/**
 * Raised when a key has exceeded its client-side retry horizon and can no longer
 * be safely reused for the same operation.
 */
declare class IdempotencyExpiredError extends Error {
    readonly operationId: string;
    constructor(operationId: string, message?: string);
}

/**
 * Classification of a backend response with respect to idempotency handling.
 */
type IdempotencyOutcome = 'in-progress' | 'conflict' | 'required' | 'other';
/**
 * Classify an {@link HttpErrorResponse} against the backend idempotency contract
 * (see the Juice backend `011-idempotency-key-api` feature):
 * - `409` → operation is still in progress (retry after backoff)
 * - `422` → key reused with a different payload (conflict)
 * - `400` with an idempotency-key ProblemDetails title → key required
 * - anything else → not an idempotency signal
 */
declare function classifyError(error: HttpErrorResponse): IdempotencyOutcome;

/**
 * Optional provider of a user-scoped identifier (e.g. the authenticated subject)
 * folded into the idempotency key scope so keys are never reused across a user
 * switch. Kept as a token so `@juice-js/core` does not depend on `@juice-js/auth`
 * (which would introduce a circular library dependency). Applications with auth
 * provide `{ provide: IDEMPOTENCY_USER_CONTEXT, useValue: () => oauth.getIdentityClaims()?.sub ?? null }`.
 */
declare const IDEMPOTENCY_USER_CONTEXT: InjectionToken<() => string | null>;
/**
 * Generates, stores, and reuses a collision-resistant `Idempotency-Key` per
 * logical operation. The same operation id yields the same key across retries
 * and double-submits; distinct operations get distinct keys; and keys are scoped
 * to the current tenant/user so they never leak across a context switch.
 */
declare class IdempotencyKeyService {
    private readonly tenant;
    private readonly userContext;
    private readonly entries;
    constructor(tenant: TenantService | null, userContext: (() => string | null) | null);
    private currentScope;
    private newKey;
    /**
     * Return the existing key for this operation, or generate a new one. If the
     * current tenant/user scope differs from the stored entry, a fresh key is
     * generated (FR-010).
     */
    getKey(operationId: string): string;
    /** Forget the key for a completed (or abandoned) operation. */
    release(operationId: string): void;
    /**
     * Whether the stored key for the operation has exceeded the given retry
     * horizon. Returns `false` when no horizon is set or no key exists yet.
     */
    isExpired(operationId: string, maxAgeMs: number | null | undefined): boolean;
    /**
     * UI-level double-submit guard (FR-009). Returns `false` if an operation is
     * already in flight, so callers can suppress a duplicate dispatch.
     */
    tryBeginInFlight(operationId: string): boolean;
    /** Clear the in-flight flag set by {@link tryBeginInFlight}. */
    endInFlight(operationId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdempotencyKeyService, [{ optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IdempotencyKeyService>;
}

/**
 * Attaches an `Idempotency-Key` header to opted-in state-changing requests and
 * interprets the backend idempotency responses:
 * - replayed success is passed through and the key released;
 * - `409` in-progress triggers a bounded backoff retry reusing the same key;
 * - `422` conflict and `400` required surface as typed errors without resubmission;
 * - keys past their retry horizon surface as an expired error.
 *
 * On top of the shared key, it de-duplicates concurrent dispatches of the same
 * operation (FR-009): while one attempt is in flight, a second subscription to
 * the same operation is coalesced onto the first in-flight response instead of
 * issuing a parallel request, so a double-click settles on a single outcome.
 *
 * Mirrors the `@juice-js/auth` `AuthInterceptor` idiom.
 */
declare class IdempotencyInterceptor implements HttpInterceptor {
    private readonly keys;
    private readonly maxInProgressRetries;
    private readonly baseBackoffMs;
    /**
     * Shared, in-flight response streams keyed by operation id. Present only while
     * an operation is being sent; cleared when it settles (success or error).
     */
    private readonly inFlight;
    constructor(keys: IdempotencyKeyService);
    private isUnsafe;
    intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable$1<HttpEvent<unknown>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdempotencyInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IdempotencyInterceptor>;
}

/**
 * Registers the {@link IdempotencyInterceptor} so opted-in state-changing
 * requests automatically carry an `Idempotency-Key` header.
 *
 * @example
 * imports: [IdempotencyModule]
 */
declare class IdempotencyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<IdempotencyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IdempotencyModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IdempotencyModule>;
}

export { AsyncDialog, IDEMPOTENCY_MAX_AGE_MS, IDEMPOTENCY_OPERATION, IDEMPOTENCY_USER_CONTEXT, IdempotencyConflictError, IdempotencyExpiredError, IdempotencyInterceptor, IdempotencyKeyRequiredError, IdempotencyKeyService, IdempotencyModule, MENUS, MenuItem, MenuModule, MenuService, TenantModule, TenantService, classifyError, loadChildrenRoutes, withIdempotency };
export type { CanDisplay, IdempotencyOutcome, Menu, Menus, TenantInfo };
