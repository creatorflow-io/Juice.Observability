import { TenantService, MenuItem, MenuService, AsyncDialog } from '@juice-js/core';
import * as i0 from '@angular/core';
import { Signal, ChangeDetectorRef, ComponentRef, ElementRef, ViewContainerRef, OnInit, ModuleWithProviders } from '@angular/core';
import { BreakpointObserver } from '@angular/cdk/layout';
import * as i8 from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router';
import { OAuthService } from 'angular-oauth2-oidc';
import * as i9 from '@angular/common';
import * as i10 from '@ngx-translate/core';
import * as i11 from '@angular/material/icon';
import * as i12 from '@angular/material/toolbar';
import * as i13 from '@angular/material/sidenav';
import * as i14 from '@angular/material/button';
import * as i15 from '@angular/material/expansion';
import * as i16 from '@angular/material/list';
import * as i17 from '@angular/material/form-field';
import * as i18 from '@angular/material/input';
import * as i19 from '@angular/material/tooltip';
import * as i2 from '@angular/material/dialog';

declare enum ThemeMode {
    Light = "light",
    Dark = "dark",
    Auto = "auto"
}
declare class LayoutConfig {
    favicon: string;
    brand: string;
    brandLogo: string;
    defaultThemeMode: ThemeMode;
    defaultLanguage: string;
    defaultMenuOpen: boolean;
    settingUrl: string | undefined;
    userImageUrl: string | undefined;
    constructor(options?: ILayoutConfig);
}
interface ILayoutConfig {
    favicon?: string;
    brand: string;
    brandLogo?: string;
    defaultThemeMode?: ThemeMode;
    defaultLanguage?: string;
    defaultMenuOpen?: boolean;
    settingUrl?: string;
    userImageUrl?: string;
}

declare class LayoutService {
    static DARK_MODE: string;
    static MENU_OPEN: string;
    private readonly _tenantIdentifier;
    private readonly _tenant;
    private _options;
    get tenantIdentifier(): string;
    set tenantIdentifier(value: string);
    constructor(options: LayoutConfig, tenantService: TenantService);
    getThemeMode(): ThemeMode;
    toggleDarkMode(): void;
    isMenuOpen(): boolean;
    toggleMenu(): void;
    favicon(): string;
    brandName(): string;
    brandLogo(): string;
    settingUrl(): string | undefined;
    userImageUrl(username: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutService, [{ optional: true; }, null]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LayoutService>;
}

/**
 * Mediates between the shell's single toolbar search box and the page on display.
 *
 * The box appears only while the displayed page implements {@link SearchablePage}.
 * The shell binds and unbinds the page from its own `router-outlet` lifecycle — this
 * service deliberately does NOT listen to router events. Revoking on `NavigationStart`
 * (as it once did) fires before guards run and before a reused component is rebuilt,
 * which silently lost the box on a cancelled navigation or a tenant switch.
 */
declare class SearchService {
    private readonly _page;
    private readonly _query;
    /** Set only by the deprecated {@link enable}. */
    private readonly _legacyCallback;
    /**
     * Whether the toolbar should offer search — true iff a page is bound.
     *
     * Derived, with no setter: presence cannot be set independently of page support.
     */
    readonly isEnabled: Signal<boolean>;
    /** What the user has currently typed for the displayed page. */
    readonly query: Signal<string>;
    /**
     * Bind the page now on display. Called by the shell on outlet activation.
     *
     * A page that does not implement {@link SearchablePage} binds nothing, leaving the
     * box hidden — support is opt-in.
     */
    bindPage(instance: unknown): void;
    /**
     * Release the page. Called by the shell on outlet deactivation.
     *
     * Also discards the query: the box is mounted once and shared, so a term left here
     * would surface on the next page, which never received it.
     */
    unbindPage(): void;
    /** Forward what the user typed to the bound page. Called by the search box. */
    submit(query: string, event?: Event): void;
    /**
     * @deprecated Implement {@link SearchablePage} on the page component instead — it ties
     * the declaration to the handler, so search cannot be claimed without being served.
     * Still functional; scheduled for removal in the next major.
     */
    enable(callback: Function): void;
    /**
     * @deprecated The shell now revokes automatically when the page changes; there is
     * nothing to call. Still functional; scheduled for removal in the next major.
     */
    disable(): void;
    /**
     * @deprecated Renamed to {@link submit}, which also records the query for the box.
     */
    callback(searchText: string | null, event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchService>;
}

declare class PageComponent {
    service: LayoutService;
    private search;
    private breakpointObserver;
    isMobile: boolean;
    isSnavOpenned: boolean;
    constructor(service: LayoutService, search: SearchService, breakpointObserver: BreakpointObserver, cdr: ChangeDetectorRef);
    hideSidenavOnMobile(): void;
    toggleSidenav(): void;
    toolbarHeight(): string;
    /**
     * The routed page just became visible — offer search if it supports it.
     *
     * Driven by the outlet rather than by router events on purpose: the outlet does not
     * deactivate for a cancelled navigation or a param-only change that reuses the
     * component, so the box correctly survives both.
     */
    onPageActivate(instance: unknown): void;
    /** The routed page is going away — take the search box with it. */
    onPageDeactivate(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageComponent, "app-page", never, {}, {}, never, never, false, never>;
}

declare class DarkModeComponent {
    private service;
    ThemeMode: typeof ThemeMode;
    prefersDark: MediaQueryList;
    constructor(service: LayoutService);
    icons: Map<ThemeMode, string>;
    names: Map<ThemeMode, string>;
    name: string;
    icon: string;
    toggleDarkMode(): void;
    initTheme(prefersDark?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DarkModeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DarkModeComponent, "juice-dark-mode", never, {}, {}, never, never, false, never>;
}

declare enum TooltipPosition {
    ABOVE = "above",
    BELOW = "below",
    LEFT = "left",
    RIGHT = "right",
    DEFAULT = "above"
}
declare class TooltipDirective {
    private elementRef;
    private viewContainerRef;
    tooltip: string;
    tooltipPosition: TooltipPosition;
    tooltipDisplay: boolean;
    componentRef?: ComponentRef<any>;
    constructor(elementRef: ElementRef, viewContainerRef: ViewContainerRef);
    onMouseEnter(): void;
    private getPosition;
    private setTooltipComponentProperties;
    onMouseLeave(): void;
    ngOnDestroy(): void;
    destroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TooltipDirective, "[tooltip]", never, { "tooltip": { "alias": "tooltip"; "required": false; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; }; "tooltipDisplay": { "alias": "tooltipDisplay"; "required": false; }; }, {}, never, never, false, never>;
    static ngAcceptInputType_tooltipPosition: string;
    static ngAcceptInputType_tooltipDisplay: unknown;
}

declare class NavMenuComponent {
    private service;
    layout: LayoutService;
    private tenantService;
    private route;
    private breakpointObserver;
    private cdr;
    isExpanded: boolean;
    isMobile: boolean;
    items: MenuItem[];
    TooltipPosition: typeof TooltipPosition;
    settingUrl: string | null | undefined;
    constructor(service: MenuService, layout: LayoutService, tenantService: TenantService, route: ActivatedRoute, breakpointObserver: BreakpointObserver, cdr: ChangeDetectorRef);
    toggle(): void;
    mouseEnter(): void;
    mouseLeave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavMenuComponent, "juice-nav-menu", never, {}, {}, never, never, false, never>;
}

declare class ExpandableMenuComponent {
    router: Router;
    isExpanded: boolean;
    item: MenuItem;
    TooltipPosition: typeof TooltipPosition;
    constructor(router: Router);
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpandableMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExpandableMenuComponent, "juice-expandable-menu", never, { "isExpanded": { "alias": "isExpanded"; "required": false; }; "item": { "alias": "item"; "required": false; }; }, {}, never, never, false, never>;
}

declare class PageNotfoundComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<PageNotfoundComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageNotfoundComponent, "juice-page-notfound", never, {}, {}, never, never, false, never>;
}

/**
 * The shell's single search box. Mounted once by the toolbar and shared by every page,
 * so it deliberately owns no state of its own: both its visibility and its text come
 * from {@link SearchService}, which scopes them to the page on display. A query held
 * here would outlive the page that was searched and surface on the next one.
 */
declare class SearchBarComponent {
    service: SearchService;
    constructor(service: SearchService);
    onSearchTextChange(event: Event): void;
    clear(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchBarComponent, "juice-search-bar", never, {}, {}, never, never, false, never>;
}

declare abstract class ProfileDialogService extends AsyncDialog<any, string> {
}

/**
 * Toolbar user avatar, or a "Login" button while nobody is signed in.
 *
 * The shell renders before a login completes (and before a stored session is refreshed), so the signed-in state is
 * evaluated in ngOnInit and again on every OAuth event. Async results mark the view for check, so the component
 * also renders in zoneless apps (the Angular 22 default).
 */
declare class UserProfileComponent implements OnInit {
    private dialogService;
    private layoutService;
    private oauthService;
    private router;
    private cdr;
    imageUrl: string;
    imageFailed: boolean;
    initials: string;
    authenticated: boolean;
    isProduction: boolean;
    get anonymous(): boolean;
    constructor(dialogService: ProfileDialogService, layoutService: LayoutService, oauthService: OAuthService, router: Router, cdr: ChangeDetectorRef);
    ngOnInit(): void;
    /** Starts the code flow; the login-completed page navigates back to the current route. */
    login(): Promise<void>;
    initImageUrl(): void;
    /** Syncs the avatar / login button with the token state. */
    private updateState;
    private setImageUrl;
    private computeInitials;
    onImageError(): void;
    onClick(): void;
    /**
     * Signed in = a usable access token. The id token is not required here: it is short-lived and a refresh-token
     * grant may not renew it, so it can be expired while the session (and its stored claims) is still valid.
     */
    private hasValidToken;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileComponent, [{ optional: true; }, null, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserProfileComponent, "juice-user-profile", never, {}, {}, never, never, false, never>;
}

declare class LayoutModule {
    static forRoot(production: boolean, options: ILayoutConfig): ModuleWithProviders<LayoutModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LayoutModule, [typeof PageComponent, typeof DarkModeComponent, typeof NavMenuComponent, typeof ExpandableMenuComponent, typeof PageNotfoundComponent, typeof SearchBarComponent, typeof UserProfileComponent], [typeof i8.RouterModule, typeof i9.CommonModule, typeof i10.TranslatePipe, typeof i10.TranslateDirective, typeof i11.MatIconModule, typeof i12.MatToolbarModule, typeof i13.MatSidenavModule, typeof i14.MatButtonModule, typeof i15.MatExpansionModule, typeof i16.MatListModule, typeof i17.MatFormFieldModule, typeof i18.MatInputModule, typeof i19.MatTooltipModule], [typeof PageComponent, typeof i8.RouterModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LayoutModule>;
}

declare class TooltipComponent {
    private elementRef;
    tooltip: string;
    position: TooltipPosition;
    left: number;
    top: number;
    display: boolean;
    constructor(elementRef: ElementRef);
    calculatePosition(left: number, right: number, top: number, bottom: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TooltipComponent, "tooltip", never, {}, {}, never, never, false, never>;
}

declare class TooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TooltipModule, [typeof TooltipComponent, typeof TooltipDirective], [typeof i9.CommonModule], [typeof TooltipDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TooltipModule>;
}

declare class DevGuard {
    isProduction: boolean;
    canActivate(): boolean;
    canDisplay(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DevGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DevGuard>;
}

/**
 * Implemented by a routed page to declare that it supports search.
 *
 * The shell's toolbar hosts one search box, shared by every page. It appears only
 * while the displayed page implements this interface, and disappears otherwise —
 * there is nothing else to opt in to and no flag to set.
 *
 * Implementing `onSearch` IS the declaration: support and handling cannot be
 * declared apart, so a box that accepts typing no page listens to is impossible.
 *
 * @example
 * export class OrdersComponent implements SearchablePage {
 *   onSearch(query: string): void {
 *     this.filter = query;   // '' means the box was cleared — show everything
 *   }
 * }
 */
interface SearchablePage {
    /**
     * Called as the user types, and once with `''` when the box is cleared.
     * An empty query means "show everything" — it is not the same as the box being
     * absent, which calls nothing at all.
     *
     * Called on every keystroke: the shell does not debounce, impose a minimum
     * length, or wait for Enter. A page that wants any of those owns them.
     * Must not throw — the shell does not catch.
     *
     * @param query What the user has typed. Never null; `''` when cleared.
     * @param event The originating DOM event, when there is one.
     */
    onSearch(query: string, event?: Event): void;
}
/**
 * Structural type guard used by the shell to detect {@link SearchablePage}.
 *
 * TypeScript interfaces are erased at runtime, so support is detected by shape
 * rather than by nominal type. See research.md Decision 1 for the trade-off.
 */
declare function isSearchablePage(value: unknown): value is SearchablePage;

declare class UserProfileDialogComponent implements OnInit {
    private auth;
    private cdr;
    username: string;
    name: string;
    email: string;
    loggedin: boolean;
    constructor(auth: OAuthService, cdr: ChangeDetectorRef);
    ngOnInit(): void;
    setValues(claims: any): void;
    logout(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserProfileDialogComponent, "app-user-profile", never, {}, {}, never, never, false, never>;
}

declare class UserProfileDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserProfileDialogModule, [typeof UserProfileDialogComponent], [typeof i2.MatDialogModule, typeof i14.MatButtonModule, typeof i10.TranslatePipe, typeof i10.TranslateDirective, typeof i9.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserProfileDialogModule>;
}

export { DevGuard, ExpandableMenuComponent, LayoutModule, LayoutService, NavMenuComponent, PageComponent, PageNotfoundComponent, ProfileDialogService, SearchService, TooltipDirective, TooltipModule, TooltipPosition, UserProfileDialogModule, isSearchablePage };
export type { SearchablePage };
