import * as i0 from '@angular/core';
import { InjectionToken, signal, Optional, Injectable, computed, ChangeDetectionStrategy, Component, booleanAttribute, HostListener, Input, Directive, inject, HostBinding, NgModule } from '@angular/core';
import * as i1 from '@juice-js/core';
import { AsyncDialog } from '@juice-js/core';
import * as i4$2 from '@angular/cdk/layout';
import { Breakpoints } from '@angular/cdk/layout';
import { trigger, transition, style, animate, state } from '@angular/animations';
import * as i1$2 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i5 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i6$1 from '@angular/material/toolbar';
import { MatToolbarModule } from '@angular/material/toolbar';
import * as i7 from '@angular/material/sidenav';
import { MatSidenavModule } from '@angular/material/sidenav';
import * as i3 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i4 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i5$1 from '@ngx-translate/core';
import { TranslatePipe, TranslateDirective } from '@ngx-translate/core';
import * as i1$1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i6 from '@angular/material/list';
import { MatListModule } from '@angular/material/list';
import * as i4$1 from '@angular/material/expansion';
import { MatExpansionModule } from '@angular/material/expansion';
import * as i3$1 from 'angular-oauth2-oidc';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import * as i2 from '@angular/material/dialog';
import { MatDialogModule } from '@angular/material/dialog';

var ThemeMode;
(function (ThemeMode) {
    ThemeMode["Light"] = "light";
    ThemeMode["Dark"] = "dark";
    ThemeMode["Auto"] = "auto";
})(ThemeMode || (ThemeMode = {}));
class LayoutConfig {
    constructor(options) {
        this.favicon = "favicon.ico";
        this.brand = "Juice";
        this.brandLogo = "assets/images/logo.png";
        this.defaultThemeMode = ThemeMode.Auto;
        this.defaultLanguage = "en-US";
        this.defaultMenuOpen = false;
        if (options) {
            Object.assign(this, options);
        }
    }
}
const IS_PRODUCTION = new InjectionToken('production');

class LayoutService {
    static { this.DARK_MODE = "IS_DARK_MODE"; }
    static { this.MENU_OPEN = "IS_MENU_OPEN"; }
    get tenantIdentifier() {
        return this._tenantIdentifier();
    }
    set tenantIdentifier(value) {
        this._tenantIdentifier.set(value);
    }
    constructor(options, tenantService) {
        // Signals, not plain fields: the tenant arrives after the shell has rendered, and templates reading
        // brandName()/brandLogo()/tenantIdentifier must re-render then, also in zoneless apps.
        this._tenantIdentifier = signal("", /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "_tenantIdentifier" }] : /* istanbul ignore next */ []));
        this._tenant = signal(null, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "_tenant" }] : /* istanbul ignore next */ []));
        tenantService?.getTenantInfo().then(tenantInfo => {
            this._tenantIdentifier.set(tenantInfo?.identifier ?? "");
            this._tenant.set(tenantInfo);
        });
        this._options = options ?? new LayoutConfig();
    }
    getThemeMode() {
        let mode = localStorage.getItem(LayoutService.DARK_MODE);
        if (mode) {
            return JSON.parse(mode);
        }
        return this._options.defaultThemeMode;
    }
    toggleDarkMode() {
        var state = this.getThemeMode();
        if (state == ThemeMode.Auto) {
            state = ThemeMode.Light;
        }
        else if (state == ThemeMode.Light) {
            state = ThemeMode.Dark;
        }
        else {
            state = ThemeMode.Auto;
        }
        localStorage.setItem(LayoutService.DARK_MODE, JSON.stringify(state));
    }
    isMenuOpen() {
        let isMenuOpen = localStorage.getItem(LayoutService.MENU_OPEN);
        if (isMenuOpen) {
            return JSON.parse(isMenuOpen);
        }
        return this._options.defaultMenuOpen;
    }
    toggleMenu() {
        let state = !this.isMenuOpen();
        localStorage.setItem(LayoutService.MENU_OPEN, JSON.stringify(state));
    }
    favicon() {
        return this._tenant()?.favicon ?? this._options.favicon;
    }
    brandName() {
        return this._tenant()?.name ?? this._options.brand;
    }
    brandLogo() {
        return this._tenant()?.logo ?? this._options.brandLogo;
    }
    settingUrl() {
        return this._options.settingUrl;
    }
    userImageUrl(username) {
        return this._options.userImageUrl ? this._options.userImageUrl.replace("{username}", username) : "";
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LayoutService, deps: [{ token: LayoutConfig, optional: true }, { token: i1.TenantService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LayoutService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LayoutService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: LayoutConfig, decorators: [{
                    type: Optional
                }] }, { type: i1.TenantService }] });

/**
 * Structural type guard used by the shell to detect {@link SearchablePage}.
 *
 * TypeScript interfaces are erased at runtime, so support is detected by shape
 * rather than by nominal type. See research.md Decision 1 for the trade-off.
 */
function isSearchablePage(value) {
    return (typeof value === 'object' &&
        value !== null &&
        typeof value.onSearch === 'function');
}

/**
 * Mediates between the shell's single toolbar search box and the page on display.
 *
 * The box appears only while the displayed page implements {@link SearchablePage}.
 * The shell binds and unbinds the page from its own `router-outlet` lifecycle — this
 * service deliberately does NOT listen to router events. Revoking on `NavigationStart`
 * (as it once did) fires before guards run and before a reused component is rebuilt,
 * which silently lost the box on a cancelled navigation or a tenant switch.
 */
class SearchService {
    constructor() {
        this._page = signal(null, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "_page" }] : /* istanbul ignore next */ []));
        this._query = signal('', /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "_query" }] : /* istanbul ignore next */ []));
        /** Set only by the deprecated {@link enable}. */
        this._legacyCallback = signal(null, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "_legacyCallback" }] : /* istanbul ignore next */ []));
        /**
         * Whether the toolbar should offer search — true iff a page is bound.
         *
         * Derived, with no setter: presence cannot be set independently of page support.
         */
        this.isEnabled = computed(() => this._page() !== null || this._legacyCallback() !== null, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "isEnabled" }] : /* istanbul ignore next */ []));
        /** What the user has currently typed for the displayed page. */
        this.query = this._query.asReadonly();
    }
    /**
     * Bind the page now on display. Called by the shell on outlet activation.
     *
     * A page that does not implement {@link SearchablePage} binds nothing, leaving the
     * box hidden — support is opt-in.
     */
    bindPage(instance) {
        this._page.set(isSearchablePage(instance) ? instance : null);
    }
    /**
     * Release the page. Called by the shell on outlet deactivation.
     *
     * Also discards the query: the box is mounted once and shared, so a term left here
     * would surface on the next page, which never received it.
     */
    unbindPage() {
        this._page.set(null);
        this._legacyCallback.set(null);
        this._query.set('');
    }
    /** Forward what the user typed to the bound page. Called by the search box. */
    submit(query, event) {
        this._query.set(query);
        const page = this._page();
        if (page) {
            page.onSearch(query, event);
            return;
        }
        const legacy = this._legacyCallback();
        if (legacy) {
            legacy(query, event);
        }
    }
    /**
     * @deprecated Implement {@link SearchablePage} on the page component instead — it ties
     * the declaration to the handler, so search cannot be claimed without being served.
     * Still functional; scheduled for removal in the next major.
     */
    enable(callback) {
        this._legacyCallback.set(callback);
    }
    /**
     * @deprecated The shell now revokes automatically when the page changes; there is
     * nothing to call. Still functional; scheduled for removal in the next major.
     */
    disable() {
        this._page.set(null);
        this._legacyCallback.set(null);
    }
    /**
     * @deprecated Renamed to {@link submit}, which also records the query for the box.
     */
    callback(searchText, event) {
        this.submit(searchText ?? '', event);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SearchService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SearchService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SearchService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class DarkModeComponent {
    constructor(service) {
        this.service = service;
        this.ThemeMode = ThemeMode;
        this.prefersDark = window.matchMedia("(prefers-color-scheme: dark)");
        this.icons = new Map([
            [ThemeMode.Light, "light_mode"],
            [ThemeMode.Dark, "dark_mode"],
            [ThemeMode.Auto, "adjust"]
        ]);
        this.names = new Map([
            [ThemeMode.Light, "Light"],
            [ThemeMode.Dark, "Dark"],
            [ThemeMode.Auto, "Adaptive"]
        ]);
        this.name = "";
        this.icon = "light_mode";
        this.prefersDark.addEventListener("change", e => {
            this.initTheme(e.matches);
        });
        this.initTheme(this.prefersDark.matches);
    }
    toggleDarkMode() {
        this.service.toggleDarkMode();
        this.initTheme(this.prefersDark.matches);
    }
    initTheme(prefersDark = false) {
        var mode = this.service.getThemeMode();
        var scheme = mode == ThemeMode.Auto ? prefersDark ? ThemeMode.Dark : ThemeMode.Light
            : mode;
        document.body.classList.remove("dark");
        if (scheme == ThemeMode.Dark) {
            document.body.classList.add(scheme);
        }
        this.icon = this.icons.get(mode) ?? "";
        this.name = this.names.get(mode) ?? "";
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: DarkModeComponent, deps: [{ token: LayoutService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.6", type: DarkModeComponent, isStandalone: false, selector: "juice-dark-mode", ngImport: i0, template: "<button mat-icon-button (click)=\"toggleDarkMode()\" matTooltip=\"{{ name | translate }}\" matTooltipPosition=\"left\"><mat-icon>{{icon}}</mat-icon></button>", dependencies: [{ kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i3.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: i4.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: i5$1.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: DarkModeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'juice-dark-mode', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<button mat-icon-button (click)=\"toggleDarkMode()\" matTooltip=\"{{ name | translate }}\" matTooltipPosition=\"left\"><mat-icon>{{icon}}</mat-icon></button>" }]
        }], ctorParameters: () => [{ type: LayoutService }] });

class TooltipComponent {
    constructor(elementRef) {
        this.elementRef = elementRef;
        this.tooltip = '';
        this.position = TooltipPosition.DEFAULT;
        this.left = 0;
        this.top = 0;
        this.display = true;
    }
    calculatePosition(left, right, top, bottom) {
        switch (this.position) {
            case TooltipPosition.BELOW: {
                this.left = Math.round((right - left) / 2 + left);
                this.top = Math.round(bottom);
                break;
            }
            case TooltipPosition.ABOVE: {
                this.left = Math.round((right - left) / 2 + left);
                this.top = Math.round(top);
                break;
            }
            case TooltipPosition.RIGHT: {
                this.left = Math.round(right);
                this.top = Math.round(top + (bottom - top) / 2);
                break;
            }
            case TooltipPosition.LEFT: {
                this.left = Math.round(left);
                this.top = Math.round(top + (bottom - top) / 2);
                break;
            }
            default: {
                break;
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TooltipComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: TooltipComponent, isStandalone: false, selector: "tooltip", ngImport: i0, template: "@if (display) {\r\n  <div #tooltipId class=\"tooltip\" [ngClass]=\"['tooltip--'+position]\"\r\n    [style.left]=\"left + 'px'\" [style.top]=\"top + 'px'\">\r\n    {{tooltip}}\r\n  </div>\r\n}", styles: [".tooltip{position:fixed;background-color:#000;border-radius:4px;color:#fff;font-family:Arial;padding:3px 6px;font-size:13px;z-index:9999}.tooltip:before{content:\"\";width:0;height:0;position:absolute}.tooltip--visible{opacity:1;transition:opacity .3s}.tooltip--light{background-color:#fff;color:#000}.tooltip--light:before{border:5px solid white}.tooltip--dark{background-color:#000;color:#fff}.tooltip--dark:before{border:5px solid black}.tooltip--below{transform:translate(-50%);margin-top:7px}.tooltip--below:before{border-left-color:transparent;border-right-color:transparent;border-top:none;left:calc(50% - 5px);top:-5px}.tooltip--above{transform:translate(-50%,-100%);margin-bottom:7px}.tooltip--above:before{border-left-color:transparent;border-right-color:transparent;border-bottom:none;left:calc(50% - 5px);bottom:-5px}.tooltip--left{transform:translate(calc(-100% - 7px),-50%)}.tooltip--left:before{border-top-color:transparent;border-bottom-color:transparent;border-right:none;right:-5px;top:calc(50% - 5px)}.tooltip--right{transform:translateY(-50%);margin-left:7px}.tooltip--right:before{border-top-color:transparent;border-bottom-color:transparent;border-left:none;left:-5px;top:calc(50% - 5px)}.tooltip--dynamic{margin-left:20px}.tooltip--dynamic:before{display:none}\n"], dependencies: [{ kind: "directive", type: i1$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TooltipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'tooltip', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "@if (display) {\r\n  <div #tooltipId class=\"tooltip\" [ngClass]=\"['tooltip--'+position]\"\r\n    [style.left]=\"left + 'px'\" [style.top]=\"top + 'px'\">\r\n    {{tooltip}}\r\n  </div>\r\n}", styles: [".tooltip{position:fixed;background-color:#000;border-radius:4px;color:#fff;font-family:Arial;padding:3px 6px;font-size:13px;z-index:9999}.tooltip:before{content:\"\";width:0;height:0;position:absolute}.tooltip--visible{opacity:1;transition:opacity .3s}.tooltip--light{background-color:#fff;color:#000}.tooltip--light:before{border:5px solid white}.tooltip--dark{background-color:#000;color:#fff}.tooltip--dark:before{border:5px solid black}.tooltip--below{transform:translate(-50%);margin-top:7px}.tooltip--below:before{border-left-color:transparent;border-right-color:transparent;border-top:none;left:calc(50% - 5px);top:-5px}.tooltip--above{transform:translate(-50%,-100%);margin-bottom:7px}.tooltip--above:before{border-left-color:transparent;border-right-color:transparent;border-bottom:none;left:calc(50% - 5px);bottom:-5px}.tooltip--left{transform:translate(calc(-100% - 7px),-50%)}.tooltip--left:before{border-top-color:transparent;border-bottom-color:transparent;border-right:none;right:-5px;top:calc(50% - 5px)}.tooltip--right{transform:translateY(-50%);margin-left:7px}.tooltip--right:before{border-top-color:transparent;border-bottom-color:transparent;border-left:none;left:-5px;top:calc(50% - 5px)}.tooltip--dynamic{margin-left:20px}.tooltip--dynamic:before{display:none}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }] });

var TooltipPosition;
(function (TooltipPosition) {
    TooltipPosition["ABOVE"] = "above";
    TooltipPosition["BELOW"] = "below";
    TooltipPosition["LEFT"] = "left";
    TooltipPosition["RIGHT"] = "right";
    TooltipPosition["DEFAULT"] = "above";
})(TooltipPosition || (TooltipPosition = {}));
function tooltipPosition(position) {
    switch (position) {
        case TooltipPosition.ABOVE: return TooltipPosition.ABOVE;
        case TooltipPosition.BELOW: return TooltipPosition.BELOW;
        case TooltipPosition.LEFT: return TooltipPosition.LEFT;
        case TooltipPosition.RIGHT: return TooltipPosition.RIGHT;
        default: return TooltipPosition.DEFAULT;
    }
}
class TooltipDirective {
    constructor(elementRef, viewContainerRef) {
        this.elementRef = elementRef;
        this.viewContainerRef = viewContainerRef;
        this.tooltip = '';
        this.tooltipPosition = TooltipPosition.DEFAULT;
    }
    onMouseEnter() {
        if (!this.componentRef) {
            this.componentRef = this.viewContainerRef.createComponent(TooltipComponent);
            const domElem = this.componentRef.hostView
                .rootNodes[0];
            document.body.appendChild(domElem);
            this.setTooltipComponentProperties();
        }
    }
    getPosition() {
        return this.tooltipPosition;
    }
    setTooltipComponentProperties() {
        if (this.componentRef) {
            this.componentRef.instance.tooltip = this.tooltip;
            this.componentRef.instance.position = this.getPosition();
            this.componentRef.instance.display = this.tooltipDisplay;
            const { left, right, top, bottom } = this.elementRef.nativeElement.getBoundingClientRect();
            this.componentRef.instance.calculatePosition(left, right, top, bottom);
        }
    }
    onMouseLeave() {
        this.destroy();
    }
    ngOnDestroy() {
        this.destroy();
    }
    destroy() {
        if (this.componentRef) {
            this.componentRef.destroy();
            this.componentRef = undefined;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TooltipDirective, deps: [{ token: i0.ElementRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "16.1.0", version: "22.0.6", type: TooltipDirective, isStandalone: false, selector: "[tooltip]", inputs: { tooltip: "tooltip", tooltipPosition: ["tooltipPosition", "tooltipPosition", tooltipPosition], tooltipDisplay: ["tooltipDisplay", "tooltipDisplay", booleanAttribute] }, host: { listeners: { "mouseenter": "onMouseEnter()", "mouseleave": "onMouseLeave()" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[tooltip]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ViewContainerRef }], propDecorators: { tooltip: [{
                type: Input
            }], tooltipPosition: [{
                type: Input,
                args: [{ transform: tooltipPosition }]
            }], tooltipDisplay: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], onMouseEnter: [{
                type: HostListener,
                args: ['mouseenter']
            }], onMouseLeave: [{
                type: HostListener,
                args: ['mouseleave']
            }] } });

class ExpandableMenuComponent {
    constructor(router) {
        this.router = router;
        this.isExpanded = false;
        this.item = {};
        this.TooltipPosition = TooltipPosition;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: ExpandableMenuComponent, deps: [{ token: i1$2.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: ExpandableMenuComponent, isStandalone: false, selector: "juice-expandable-menu", inputs: { isExpanded: "isExpanded", item: "item" }, ngImport: i0, template: "<mat-expansion-panel [expanded]=\"item.routerLink ? router.isActive(item.routerLink, false) : false\" [hideToggle]=\"!isExpanded\" [ngClass]=\"(item.routerLink && router.isActive(item.routerLink, false)) ? 'active' : ''\">\r\n  <mat-expansion-panel-header >\r\n    <mat-list-item routerLink=\"{{ item.routerLink }}\" [routerLinkActive]=\"['active']\"\r\n      [routerLinkActiveOptions]=\"{exact: true}\">\r\n      <mat-icon matListItemIcon>{{ item.icon }}</mat-icon>\r\n      @if (isExpanded) {\r\n        <span matListItemTitle style=\"margin-left: 4px;\"> {{ item.label }}</span>\r\n      }\r\n    </mat-list-item>\r\n  </mat-expansion-panel-header>\r\n  <mat-nav-list>\r\n    @for ( subitem of item.children ; track  subitem) {\r\n      <mat-list-item routerLink=\"{{ subitem.routerLink }}\" [routerLinkActive]=\"['active']\"\r\n        [routerLinkActiveOptions]=\"{exact: true}\">\r\n        <mat-icon matListItemIcon>{{ subitem.icon }}</mat-icon>\r\n        @if (isExpanded) {\r\n          <span matListItemTitle style=\"margin-left: 4px;\"> {{ subitem.label }}</span>\r\n        }\r\n      </mat-list-item>\r\n    }\r\n  </mat-nav-list>\r\n</mat-expansion-panel>\r\n", styles: [":host ::ng-deep .mat-expansion-panel-header{padding:0}:host ::ng-deep .mat-expansion-panel-header .mdc-list-item{padding:0}:host ::ng-deep .mat-expansion-panel-header .mat-expansion-indicator{position:absolute;right:0;padding:16px}:host ::ng-deep .mat-expansion-panel-body{padding:0}:host ::ng-deep .mat-content.mat-content-hide-toggle{margin-right:0}\n"], dependencies: [{ kind: "directive", type: i1$2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "directive", type: i1$2.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "directive", type: i1$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4$1.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i4$1.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "component", type: i6.MatNavList, selector: "mat-nav-list", exportAs: ["matNavList"] }, { kind: "component", type: i6.MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["activated"], exportAs: ["matListItem"] }, { kind: "directive", type: i6.MatListItemIcon, selector: "[matListItemIcon]" }, { kind: "directive", type: i6.MatListItemTitle, selector: "[matListItemTitle]" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: ExpandableMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'juice-expandable-menu', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<mat-expansion-panel [expanded]=\"item.routerLink ? router.isActive(item.routerLink, false) : false\" [hideToggle]=\"!isExpanded\" [ngClass]=\"(item.routerLink && router.isActive(item.routerLink, false)) ? 'active' : ''\">\r\n  <mat-expansion-panel-header >\r\n    <mat-list-item routerLink=\"{{ item.routerLink }}\" [routerLinkActive]=\"['active']\"\r\n      [routerLinkActiveOptions]=\"{exact: true}\">\r\n      <mat-icon matListItemIcon>{{ item.icon }}</mat-icon>\r\n      @if (isExpanded) {\r\n        <span matListItemTitle style=\"margin-left: 4px;\"> {{ item.label }}</span>\r\n      }\r\n    </mat-list-item>\r\n  </mat-expansion-panel-header>\r\n  <mat-nav-list>\r\n    @for ( subitem of item.children ; track  subitem) {\r\n      <mat-list-item routerLink=\"{{ subitem.routerLink }}\" [routerLinkActive]=\"['active']\"\r\n        [routerLinkActiveOptions]=\"{exact: true}\">\r\n        <mat-icon matListItemIcon>{{ subitem.icon }}</mat-icon>\r\n        @if (isExpanded) {\r\n          <span matListItemTitle style=\"margin-left: 4px;\"> {{ subitem.label }}</span>\r\n        }\r\n      </mat-list-item>\r\n    }\r\n  </mat-nav-list>\r\n</mat-expansion-panel>\r\n", styles: [":host ::ng-deep .mat-expansion-panel-header{padding:0}:host ::ng-deep .mat-expansion-panel-header .mdc-list-item{padding:0}:host ::ng-deep .mat-expansion-panel-header .mat-expansion-indicator{position:absolute;right:0;padding:16px}:host ::ng-deep .mat-expansion-panel-body{padding:0}:host ::ng-deep .mat-content.mat-content-hide-toggle{margin-right:0}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.Router }], propDecorators: { isExpanded: [{
                type: Input
            }], item: [{
                type: Input
            }] } });

class NavMenuComponent {
    constructor(service, layout, tenantService, route, breakpointObserver, cdr) {
        this.service = service;
        this.layout = layout;
        this.tenantService = tenantService;
        this.route = route;
        this.breakpointObserver = breakpointObserver;
        this.cdr = cdr;
        this.isExpanded = false;
        this.isMobile = false;
        this.items = [];
        this.TooltipPosition = TooltipPosition;
        if (route.snapshot.data['settingUrl']) {
            this.settingUrl = route.snapshot.data['settingUrl'];
        }
        else {
            this.settingUrl = layout.settingUrl();
        }
        // Async callbacks don't trigger change detection in zoneless apps (the Angular 22 default), so mark explicitly.
        tenantService.getTenantIdentifier().then(tenant => {
            this.settingUrl = this.settingUrl?.injectTenant(tenant);
            this.cdr.markForCheck();
        });
        breakpointObserver.observe([
            Breakpoints.HandsetLandscape,
            Breakpoints.HandsetPortrait
        ]).subscribe(result => {
            this.isMobile = result.matches;
            this.isExpanded = result.matches ? true : this.layout.isMenuOpen();
            this.cdr.markForCheck();
        });
        this.service.getMenu().subscribe(items => {
            console.debug('Menu items', JSON.parse(JSON.stringify(items)));
            this.items = items;
            this.cdr.markForCheck();
        });
    }
    toggle() {
        this.layout.toggleMenu();
        this.isExpanded = this.layout.isMenuOpen();
    }
    mouseEnter() {
        if (!this.isMobile) {
            this.isExpanded = true;
        }
    }
    mouseLeave() {
        if (!this.isMobile) {
            this.isExpanded = this.layout.isMenuOpen();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: NavMenuComponent, deps: [{ token: i1.MenuService }, { token: LayoutService }, { token: i1.TenantService }, { token: i1$2.ActivatedRoute }, { token: i4$2.BreakpointObserver }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: NavMenuComponent, isStandalone: false, selector: "juice-nav-menu", ngImport: i0, template: "<mat-nav-list class=\"menu-scroll\" (mouseenter)=\"mouseEnter()\" (mouseleave)=\"mouseLeave()\">\r\n  @for (item of items; track item) {\r\n    @if (!item.children || item.children.length==0) {\r\n      <mat-list-item\r\n        routerLink=\"{{ item.routerLink }}\" [routerLinkActive]=\"['active']\"\r\n        [routerLinkActiveOptions]=\"{exact:true}\">\r\n        <mat-icon matListItemIcon color=\"accent\">{{ item.icon }}</mat-icon>\r\n        <span matListItemTitle  style=\"margin-left: 4px;\"> {{ item.label }}</span>\r\n      </mat-list-item>\r\n    }\r\n    @if (item.children && item.children.length>0) {\r\n      <juice-expandable-menu\r\n      [item]=\"item\" [isExpanded]=\"isExpanded\"></juice-expandable-menu>\r\n    }\r\n  }\r\n</mat-nav-list>\r\n<mat-divider></mat-divider>\r\n<mat-action-list class=\"list-horizontal bottom-menu\">\r\n  @if (settingUrl) {\r\n    <a mat-list-item [href]=\"settingUrl\"\r\n      matTooltip=\"{{'Settings' | translate}}\" matTooltipPosition=\"right\" [matTooltipDisabled]=\"isExpanded\">\r\n      <mat-icon>settings</mat-icon>\r\n    </a>\r\n  }\r\n  @if (!isMobile) {\r\n    <button mat-list-item (click)=\"toggle()\">\r\n      <mat-icon [style.transform]= \"isExpanded ? 'rotate(-180deg)':'rotate(0)'\">double_arrow</mat-icon>\r\n    </button>\r\n  }\r\n</mat-action-list>", styles: [":host ::ng-deep{display:flex;flex-direction:column;justify-content:space-between;height:100%}:host ::ng-deep .menu-scroll{overflow-y:auto;overflow-x:hidden;flex:1}:host ::ng-deep .menu-scroll .mdc-list-item.mdc-list-item--with-one-line .mdc-list-item__start{margin-right:10px}:host ::ng-deep .list-horizontal{display:flex;flex-direction:row;flex-wrap:wrap;justify-content:flex-end}:host ::ng-deep .list-horizontal .mat-mdc-list-item{width:auto;flex:1 auto}:host ::ng-deep .list-horizontal .mat-mdc-list-item .mdc-list-item__content{display:flex;justify-content:center}:host ::ng-deep .list-horizontal .mat-mdc-list-item .mdc-list-item__content .mat-mdc-list-item-unscoped-content{padding-top:5px}:host ::ng-deep .mat-mdc-list-base{padding:0}\n"], dependencies: [{ kind: "directive", type: i1$2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "directive", type: i1$2.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i6.MatActionList, selector: "mat-action-list", exportAs: ["matActionList"] }, { kind: "component", type: i6.MatNavList, selector: "mat-nav-list", exportAs: ["matNavList"] }, { kind: "component", type: i6.MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["activated"], exportAs: ["matListItem"] }, { kind: "directive", type: i6.MatListItemIcon, selector: "[matListItemIcon]" }, { kind: "component", type: i6.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "directive", type: i6.MatListItemTitle, selector: "[matListItemTitle]" }, { kind: "directive", type: i4.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: ExpandableMenuComponent, selector: "juice-expandable-menu", inputs: ["isExpanded", "item"] }, { kind: "pipe", type: i5$1.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: NavMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'juice-nav-menu', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<mat-nav-list class=\"menu-scroll\" (mouseenter)=\"mouseEnter()\" (mouseleave)=\"mouseLeave()\">\r\n  @for (item of items; track item) {\r\n    @if (!item.children || item.children.length==0) {\r\n      <mat-list-item\r\n        routerLink=\"{{ item.routerLink }}\" [routerLinkActive]=\"['active']\"\r\n        [routerLinkActiveOptions]=\"{exact:true}\">\r\n        <mat-icon matListItemIcon color=\"accent\">{{ item.icon }}</mat-icon>\r\n        <span matListItemTitle  style=\"margin-left: 4px;\"> {{ item.label }}</span>\r\n      </mat-list-item>\r\n    }\r\n    @if (item.children && item.children.length>0) {\r\n      <juice-expandable-menu\r\n      [item]=\"item\" [isExpanded]=\"isExpanded\"></juice-expandable-menu>\r\n    }\r\n  }\r\n</mat-nav-list>\r\n<mat-divider></mat-divider>\r\n<mat-action-list class=\"list-horizontal bottom-menu\">\r\n  @if (settingUrl) {\r\n    <a mat-list-item [href]=\"settingUrl\"\r\n      matTooltip=\"{{'Settings' | translate}}\" matTooltipPosition=\"right\" [matTooltipDisabled]=\"isExpanded\">\r\n      <mat-icon>settings</mat-icon>\r\n    </a>\r\n  }\r\n  @if (!isMobile) {\r\n    <button mat-list-item (click)=\"toggle()\">\r\n      <mat-icon [style.transform]= \"isExpanded ? 'rotate(-180deg)':'rotate(0)'\">double_arrow</mat-icon>\r\n    </button>\r\n  }\r\n</mat-action-list>", styles: [":host ::ng-deep{display:flex;flex-direction:column;justify-content:space-between;height:100%}:host ::ng-deep .menu-scroll{overflow-y:auto;overflow-x:hidden;flex:1}:host ::ng-deep .menu-scroll .mdc-list-item.mdc-list-item--with-one-line .mdc-list-item__start{margin-right:10px}:host ::ng-deep .list-horizontal{display:flex;flex-direction:row;flex-wrap:wrap;justify-content:flex-end}:host ::ng-deep .list-horizontal .mat-mdc-list-item{width:auto;flex:1 auto}:host ::ng-deep .list-horizontal .mat-mdc-list-item .mdc-list-item__content{display:flex;justify-content:center}:host ::ng-deep .list-horizontal .mat-mdc-list-item .mdc-list-item__content .mat-mdc-list-item-unscoped-content{padding-top:5px}:host ::ng-deep .mat-mdc-list-base{padding:0}\n"] }]
        }], ctorParameters: () => [{ type: i1.MenuService }, { type: LayoutService }, { type: i1.TenantService }, { type: i1$2.ActivatedRoute }, { type: i4$2.BreakpointObserver }, { type: i0.ChangeDetectorRef }] });

/**
 * The shell's single search box. Mounted once by the toolbar and shared by every page,
 * so it deliberately owns no state of its own: both its visibility and its text come
 * from {@link SearchService}, which scopes them to the page on display. A query held
 * here would outlive the page that was searched and surface on the next one.
 */
class SearchBarComponent {
    constructor(service) {
        this.service = service;
    }
    onSearchTextChange(event) {
        const text = event.target.value;
        this.service.submit(text, event);
    }
    clear(event) {
        this.service.submit('', event);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SearchBarComponent, deps: [{ token: SearchService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SearchBarComponent, isStandalone: false, selector: "juice-search-bar", ngImport: i0, template: "@if (service.isEnabled()) {\n  <div @enableTrigger class=\"search-container\">\n    <input type=\"search\" [value]=\"service.query()\"\n      (input)=\"onSearchTextChange($event)\" placeholder=\"Search\">\n    @if (service.query()) {\n      <mat-icon (click)=\"clear($event)\" color=\"primary\">\n      close</mat-icon>\n    }\n  </div>\n}\n", styles: [".search-container{width:200px;min-width:150px;height:100%;margin-left:2rem;margin-right:2rem;position:relative;display:flex;align-items:center;transition:width .2s ease-in-out}.search-container input{border:none;border-radius:100px;padding:5px 3em 5px 16px;line-height:normal;font-size:1rem;width:100%;max-width:240px}.search-container input:focus{border:0;outline:none}.search-container input[type=search]::-webkit-search-decoration,.search-container input[type=search]::-webkit-search-cancel-button,.search-container input[type=search]::-webkit-search-results-button,.search-container input[type=search]::-webkit-search-results-decoration{-webkit-appearance:none}.search-container:focus-within,.search-container:has(.mat-icon){width:240px}.search-container .mat-icon{position:absolute;right:.7rem;font-size:1.4rem;cursor:pointer}@media screen and (max-width:600px){.search-container{margin-left:.5rem;margin-right:.5rem}}\n"], dependencies: [{ kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], animations: [
            trigger('enableTrigger', [
                transition(':enter', [
                    style({ opacity: 0 }),
                    animate('100ms', style({ opacity: 1 })),
                ]),
                transition(':leave', [
                    animate('100ms', style({ opacity: 0 }))
                ])
            ]),
        ], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SearchBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'juice-search-bar', animations: [
                        trigger('enableTrigger', [
                            transition(':enter', [
                                style({ opacity: 0 }),
                                animate('100ms', style({ opacity: 1 })),
                            ]),
                            transition(':leave', [
                                animate('100ms', style({ opacity: 0 }))
                            ])
                        ]),
                    ], changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "@if (service.isEnabled()) {\n  <div @enableTrigger class=\"search-container\">\n    <input type=\"search\" [value]=\"service.query()\"\n      (input)=\"onSearchTextChange($event)\" placeholder=\"Search\">\n    @if (service.query()) {\n      <mat-icon (click)=\"clear($event)\" color=\"primary\">\n      close</mat-icon>\n    }\n  </div>\n}\n", styles: [".search-container{width:200px;min-width:150px;height:100%;margin-left:2rem;margin-right:2rem;position:relative;display:flex;align-items:center;transition:width .2s ease-in-out}.search-container input{border:none;border-radius:100px;padding:5px 3em 5px 16px;line-height:normal;font-size:1rem;width:100%;max-width:240px}.search-container input:focus{border:0;outline:none}.search-container input[type=search]::-webkit-search-decoration,.search-container input[type=search]::-webkit-search-cancel-button,.search-container input[type=search]::-webkit-search-results-button,.search-container input[type=search]::-webkit-search-results-decoration{-webkit-appearance:none}.search-container:focus-within,.search-container:has(.mat-icon){width:240px}.search-container .mat-icon{position:absolute;right:.7rem;font-size:1.4rem;cursor:pointer}@media screen and (max-width:600px){.search-container{margin-left:.5rem;margin-right:.5rem}}\n"] }]
        }], ctorParameters: () => [{ type: SearchService }] });

class ProfileDialogService extends AsyncDialog {
}

/**
 * Toolbar user avatar, or a "Login" button while nobody is signed in.
 *
 * The shell renders before a login completes (and before a stored session is refreshed), so the signed-in state is
 * evaluated in ngOnInit and again on every OAuth event. Async results mark the view for check, so the component
 * also renders in zoneless apps (the Angular 22 default).
 */
class UserProfileComponent {
    get anonymous() {
        return !this.authenticated;
    }
    constructor(dialogService, layoutService, oauthService, router, cdr) {
        this.dialogService = dialogService;
        this.layoutService = layoutService;
        this.oauthService = oauthService;
        this.router = router;
        this.cdr = cdr;
        this.imageUrl = "";
        this.imageFailed = false;
        this.initials = "";
        this.authenticated = false;
        this.isProduction = inject(IS_PRODUCTION);
        this.oauthService.events.subscribe((e) => {
            if (!this.isProduction && e.type === "token_received")
                console.debug('Token received', e);
            this.updateState();
        });
    }
    ngOnInit() {
        this.updateState();
        if (!this.authenticated && !this.isProduction) {
            console.debug('No valid token', this.oauthService.hasValidAccessToken(), this.oauthService.hasValidIdToken());
        }
    }
    /** Starts the code flow; the login-completed page navigates back to the current route. */
    async login() {
        if (!this.oauthService.discoveryDocumentLoaded) {
            await this.oauthService.loadDiscoveryDocument();
        }
        this.oauthService.initLoginFlow(this.router.url);
    }
    initImageUrl() {
        if (this.imageUrl) {
            return;
        }
        const claims = this.oauthService.getIdentityClaims() ?? {};
        this.initials = this.computeInitials(claims);
        if (!this.isProduction)
            console.debug('Trying to get avatar from claims');
        if (claims["picture"]) {
            this.setImageUrl(claims["picture"]);
        }
        else if (claims["avatar"]) {
            this.setImageUrl(claims["avatar"]);
        }
        else {
            const username = claims["preferred_username"];
            if (username) {
                this.setImageUrl(this.layoutService.userImageUrl(username));
            }
            else {
                if (!this.isProduction)
                    console.debug('Trying to load user profile to get avatar');
                this.oauthService.loadUserProfile().then(info => {
                    var userProfile = info;
                    if (userProfile) {
                        this.initials = this.initials || this.computeInitials(userProfile.info);
                        this.setImageUrl(this.layoutService.userImageUrl(userProfile.info.preferred_username));
                        this.cdr.markForCheck();
                    }
                    else {
                        console.warn('No user profile found', info);
                    }
                }).catch(() => {
                    // Keep the initials / icon fallback.
                });
            }
        }
    }
    /** Syncs the avatar / login button with the token state. */
    updateState() {
        const authenticated = this.hasValidToken();
        if (authenticated === this.authenticated) {
            return;
        }
        this.authenticated = authenticated;
        if (authenticated) {
            // Only on the anonymous -> signed-in transition, so thin claims don't
            // trigger a userinfo request on every OAuth event.
            this.initImageUrl();
        }
        else {
            this.imageUrl = "";
            this.initials = "";
        }
        this.cdr.markForCheck();
    }
    setImageUrl(url) {
        this.imageUrl = url ?? "";
        this.imageFailed = false;
    }
    computeInitials(claims) {
        if (!claims) {
            return "";
        }
        const name = claims["name"]
            || [claims["given_name"], claims["family_name"]].filter(Boolean).join(" ")
            || claims["preferred_username"]
            || "";
        const words = String(name).trim().split(/\s+/).filter(Boolean);
        if (words.length === 0) {
            return "";
        }
        const chars = words.length === 1
            ? words[0].slice(0, 2)
            : words[0][0] + words[words.length - 1][0];
        return chars.toUpperCase();
    }
    onImageError() {
        if (!this.isProduction)
            console.debug('Avatar image failed to load', this.imageUrl);
        this.imageFailed = true;
    }
    onClick() {
        if (this.dialogService) {
            this.dialogService.open(this.imageUrl);
        }
    }
    /**
     * Signed in = a usable access token. The id token is not required here: it is short-lived and a refresh-token
     * grant may not renew it, so it can be expired while the session (and its stored claims) is still valid.
     */
    hasValidToken() {
        return this.oauthService.hasValidAccessToken();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserProfileComponent, deps: [{ token: ProfileDialogService, optional: true }, { token: LayoutService }, { token: i3$1.OAuthService }, { token: i1$2.Router }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: UserProfileComponent, isStandalone: false, selector: "juice-user-profile", host: { properties: { "class.anonymous": "this.anonymous" } }, ngImport: i0, template: "@if (authenticated) {\r\n    <button class=\"user-image\" (click)=\"onClick()\">\r\n        @if (imageUrl && !imageFailed) {\r\n            <img [src]=\"imageUrl\" (error)=\"onImageError()\"/>\r\n        } @else if (initials) {\r\n            <span class=\"user-image-initials\">{{ initials }}</span>\r\n        } @else {\r\n            <mat-icon class=\"user-image-fallback\">account_circle</mat-icon>\r\n        }\r\n    </button>\r\n} @else {\r\n    <button mat-button class=\"login-button\" (click)=\"login()\">\r\n        <mat-icon>login</mat-icon>\r\n        {{ 'Login' | translate }}\r\n    </button>\r\n}\r\n", styles: [":host{height:100%;aspect-ratio:1/1;display:flex;padding:3px;box-sizing:border-box}:host(.anonymous){aspect-ratio:auto;align-items:center}.user-image{flex:1 auto;border:0;padding:0;background:none;container-type:size}.user-image img{width:100%;height:100%;border-radius:50%;object-fit:cover;cursor:pointer}.user-image .user-image-fallback{width:100%;height:100%;font-size:100cqh;line-height:1;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center}.user-image .user-image-initials{width:100%;height:100%;font-size:42cqh;font-weight:600;line-height:1;text-transform:uppercase;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;color:currentColor;background:#0000001f}\n"], dependencies: [{ kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i3.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "pipe", type: i5$1.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserProfileComponent, decorators: [{
            type: Component,
            args: [{ selector: 'juice-user-profile', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "@if (authenticated) {\r\n    <button class=\"user-image\" (click)=\"onClick()\">\r\n        @if (imageUrl && !imageFailed) {\r\n            <img [src]=\"imageUrl\" (error)=\"onImageError()\"/>\r\n        } @else if (initials) {\r\n            <span class=\"user-image-initials\">{{ initials }}</span>\r\n        } @else {\r\n            <mat-icon class=\"user-image-fallback\">account_circle</mat-icon>\r\n        }\r\n    </button>\r\n} @else {\r\n    <button mat-button class=\"login-button\" (click)=\"login()\">\r\n        <mat-icon>login</mat-icon>\r\n        {{ 'Login' | translate }}\r\n    </button>\r\n}\r\n", styles: [":host{height:100%;aspect-ratio:1/1;display:flex;padding:3px;box-sizing:border-box}:host(.anonymous){aspect-ratio:auto;align-items:center}.user-image{flex:1 auto;border:0;padding:0;background:none;container-type:size}.user-image img{width:100%;height:100%;border-radius:50%;object-fit:cover;cursor:pointer}.user-image .user-image-fallback{width:100%;height:100%;font-size:100cqh;line-height:1;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center}.user-image .user-image-initials{width:100%;height:100%;font-size:42cqh;font-weight:600;line-height:1;text-transform:uppercase;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;color:currentColor;background:#0000001f}\n"] }]
        }], ctorParameters: () => [{ type: ProfileDialogService, decorators: [{
                    type: Optional
                }] }, { type: LayoutService }, { type: i3$1.OAuthService }, { type: i1$2.Router }, { type: i0.ChangeDetectorRef }], propDecorators: { anonymous: [{
                type: HostBinding,
                args: ['class.anonymous']
            }] } });

class PageComponent {
    constructor(service, search, breakpointObserver, cdr) {
        this.service = service;
        this.search = search;
        this.breakpointObserver = breakpointObserver;
        this.isMobile = false;
        this.isSnavOpenned = false;
        breakpointObserver.observe([
            Breakpoints.HandsetLandscape,
            Breakpoints.HandsetPortrait
        ]).subscribe(result => {
            this.isMobile = result.matches;
            this.isSnavOpenned = !this.isMobile;
            cdr.markForCheck();
        });
    }
    hideSidenavOnMobile() {
        if (this.isMobile) {
            this.isSnavOpenned = false;
        }
    }
    toggleSidenav() {
        this.isSnavOpenned = !this.isSnavOpenned;
    }
    toolbarHeight() {
        return "48px"; // this.isMobile ? "42px" : "48px";
    }
    /**
     * The routed page just became visible — offer search if it supports it.
     *
     * Driven by the outlet rather than by router events on purpose: the outlet does not
     * deactivate for a cancelled navigation or a param-only change that reuses the
     * component, so the box correctly survives both.
     */
    onPageActivate(instance) {
        this.search.bindPage(instance);
    }
    /** The routed page is going away — take the search box with it. */
    onPageDeactivate() {
        this.search.unbindPage();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: PageComponent, deps: [{ token: LayoutService }, { token: SearchService }, { token: i4$2.BreakpointObserver }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: PageComponent, isStandalone: false, selector: "app-page", ngImport: i0, template: "<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * * The content below * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * is only a placeholder * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * and can be replaced. * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * Delete the template below * * * * * * * * * * -->\r\n<!-- * * * * * * * to get started with your project! * * * * * * * * -->\r\n<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->\r\n<div class=\"container\" [class.mobile]=\"isMobile\">\r\n  <!-- Toolbar -->\r\n  <mat-toolbar color=\"primary\" [style.height]=\"toolbarHeight()\">\r\n    @if (isMobile) {\r\n      <button mat-icon-button (click)=\"toggleSidenav()\" class=\"m-r\">\r\n        <mat-icon aria-hidden=\"false\" fontIcon=\"menu\"></mat-icon>\r\n      </button>\r\n    }\r\n    @if (!isMobile) {\r\n      <a [routerLink]=\"['/',service.tenantIdentifier]\" class=\"nav-link home\">\r\n        <img height=\"40 \" alt=\"{{service.brandName()}} Logo \" [src]=\"service.brandLogo() \" class=\"p-r \" />\r\n      </a>\r\n    }\r\n    @if (!isMobile) {\r\n      <span>{{service.brandName()}}</span>\r\n    }\r\n    <juice-search-bar></juice-search-bar>\r\n    <span class=\"toolbar-spacer \"></span>\r\n    <juice-dark-mode></juice-dark-mode>\r\n    <juice-user-profile></juice-user-profile>\r\n  </mat-toolbar>\r\n\r\n  <mat-sidenav-container>\r\n    <mat-sidenav [opened]=\"isSnavOpenned\" (closed)=\"isSnavOpenned = false\" #snav\r\n      (navigate)=\"hideSidenavOnMobile\" (click)=\"hideSidenavOnMobile\" (swipeRight)=\"hideSidenavOnMobile\"\r\n      [mode]=\"isMobile ? 'over': 'side' \"\r\n      [@menuTransition]=\" menu.isExpanded ? 'expand' : 'collapsed' \" [fixedInViewport]=\"true\"\r\n      [style.top]=\"isMobile ? toolbarHeight():0\">\r\n      <juice-nav-menu #menu [class.menu-expanded]=\"isSnavOpenned\"\r\n      [class.menu-collapsed]=\"!isSnavOpenned\"></juice-nav-menu>\r\n    </mat-sidenav>\r\n\r\n    <mat-sidenav-content style=\"margin-left: 0;\">\r\n      <router-outlet (activate)=\"onPageActivate($event)\" (deactivate)=\"onPageDeactivate()\"></router-outlet>\r\n    </mat-sidenav-content>\r\n\r\n  </mat-sidenav-container>\r\n</div>\r\n<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * * The content above * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * is only a placeholder * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * and can be replaced. * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * End of Placeholder * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->", styles: [":host .toolbar-spacer{flex:1 1 auto}:host .nav-link{display:flex;margin-right:.5em}:host .mat-sidenav-container{display:flex;flex-direction:row}:host .mat-sidenav-container .mat-drawer-side{position:relative;flex:0 auto}:host .mat-sidenav-container .mat-drawer-over{position:fixed}:host .mat-sidenav-container .mat-sidenav-content{flex:1;height:auto}:host .container{display:flex;flex-direction:column}:host .container .mat-toolbar{flex:0 0 auto}:host .container .mat-sidenav-container{flex:1 1 auto;display:flex;flex-direction:row}\n"], dependencies: [{ kind: "directive", type: i1$2.RouterOutlet, selector: "router-outlet", inputs: ["name", "routerOutletData"], outputs: ["activate", "deactivate", "attach", "detach"], exportAs: ["outlet"] }, { kind: "directive", type: i1$2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i6$1.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "component", type: i7.MatSidenav, selector: "mat-sidenav", inputs: ["fixedInViewport", "fixedTopGap", "fixedBottomGap"], exportAs: ["matSidenav"] }, { kind: "component", type: i7.MatSidenavContainer, selector: "mat-sidenav-container", exportAs: ["matSidenavContainer"] }, { kind: "component", type: i7.MatSidenavContent, selector: "mat-sidenav-content" }, { kind: "component", type: i3.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: DarkModeComponent, selector: "juice-dark-mode" }, { kind: "component", type: NavMenuComponent, selector: "juice-nav-menu" }, { kind: "component", type: SearchBarComponent, selector: "juice-search-bar" }, { kind: "component", type: UserProfileComponent, selector: "juice-user-profile" }], animations: [
            trigger('menuTransition', [
                state('expand', style({
                    width: '220px'
                })),
                state('collapsed', style({
                    width: '60px'
                })),
                transition('* => collapsed', [
                    animate('0.15s')
                ]),
                transition('* => expand', [
                    animate('0.15s')
                ])
            ]),
            trigger('contentTransition', [
                state('expand', style({
                    "margin-left": "60px"
                })),
                state('collapsed', style({
                    "margin-left": "220px"
                })),
                state("full", style({
                    "margin-left": "0"
                })),
                transition('* => collapsed', [
                    animate('0.15s')
                ]),
                transition('* => expand', [
                    animate('0.15s')
                ])
            ])
        ], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: PageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-page', animations: [
                        trigger('menuTransition', [
                            state('expand', style({
                                width: '220px'
                            })),
                            state('collapsed', style({
                                width: '60px'
                            })),
                            transition('* => collapsed', [
                                animate('0.15s')
                            ]),
                            transition('* => expand', [
                                animate('0.15s')
                            ])
                        ]),
                        trigger('contentTransition', [
                            state('expand', style({
                                "margin-left": "60px"
                            })),
                            state('collapsed', style({
                                "margin-left": "220px"
                            })),
                            state("full", style({
                                "margin-left": "0"
                            })),
                            transition('* => collapsed', [
                                animate('0.15s')
                            ]),
                            transition('* => expand', [
                                animate('0.15s')
                            ])
                        ])
                    ], changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * * The content below * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * is only a placeholder * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * and can be replaced. * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * Delete the template below * * * * * * * * * * -->\r\n<!-- * * * * * * * to get started with your project! * * * * * * * * -->\r\n<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->\r\n<div class=\"container\" [class.mobile]=\"isMobile\">\r\n  <!-- Toolbar -->\r\n  <mat-toolbar color=\"primary\" [style.height]=\"toolbarHeight()\">\r\n    @if (isMobile) {\r\n      <button mat-icon-button (click)=\"toggleSidenav()\" class=\"m-r\">\r\n        <mat-icon aria-hidden=\"false\" fontIcon=\"menu\"></mat-icon>\r\n      </button>\r\n    }\r\n    @if (!isMobile) {\r\n      <a [routerLink]=\"['/',service.tenantIdentifier]\" class=\"nav-link home\">\r\n        <img height=\"40 \" alt=\"{{service.brandName()}} Logo \" [src]=\"service.brandLogo() \" class=\"p-r \" />\r\n      </a>\r\n    }\r\n    @if (!isMobile) {\r\n      <span>{{service.brandName()}}</span>\r\n    }\r\n    <juice-search-bar></juice-search-bar>\r\n    <span class=\"toolbar-spacer \"></span>\r\n    <juice-dark-mode></juice-dark-mode>\r\n    <juice-user-profile></juice-user-profile>\r\n  </mat-toolbar>\r\n\r\n  <mat-sidenav-container>\r\n    <mat-sidenav [opened]=\"isSnavOpenned\" (closed)=\"isSnavOpenned = false\" #snav\r\n      (navigate)=\"hideSidenavOnMobile\" (click)=\"hideSidenavOnMobile\" (swipeRight)=\"hideSidenavOnMobile\"\r\n      [mode]=\"isMobile ? 'over': 'side' \"\r\n      [@menuTransition]=\" menu.isExpanded ? 'expand' : 'collapsed' \" [fixedInViewport]=\"true\"\r\n      [style.top]=\"isMobile ? toolbarHeight():0\">\r\n      <juice-nav-menu #menu [class.menu-expanded]=\"isSnavOpenned\"\r\n      [class.menu-collapsed]=\"!isSnavOpenned\"></juice-nav-menu>\r\n    </mat-sidenav>\r\n\r\n    <mat-sidenav-content style=\"margin-left: 0;\">\r\n      <router-outlet (activate)=\"onPageActivate($event)\" (deactivate)=\"onPageDeactivate()\"></router-outlet>\r\n    </mat-sidenav-content>\r\n\r\n  </mat-sidenav-container>\r\n</div>\r\n<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * * The content above * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * is only a placeholder * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * and can be replaced. * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * End of Placeholder * * * * * * * * * * * -->\r\n<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->", styles: [":host .toolbar-spacer{flex:1 1 auto}:host .nav-link{display:flex;margin-right:.5em}:host .mat-sidenav-container{display:flex;flex-direction:row}:host .mat-sidenav-container .mat-drawer-side{position:relative;flex:0 auto}:host .mat-sidenav-container .mat-drawer-over{position:fixed}:host .mat-sidenav-container .mat-sidenav-content{flex:1;height:auto}:host .container{display:flex;flex-direction:column}:host .container .mat-toolbar{flex:0 0 auto}:host .container .mat-sidenav-container{flex:1 1 auto;display:flex;flex-direction:row}\n"] }]
        }], ctorParameters: () => [{ type: LayoutService }, { type: SearchService }, { type: i4$2.BreakpointObserver }, { type: i0.ChangeDetectorRef }] });

class PageNotfoundComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: PageNotfoundComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.6", type: PageNotfoundComponent, isStandalone: false, selector: "juice-page-notfound", ngImport: i0, template: "<div class=\"container pt-4\">\n    <h1>{{'Not found' | translate }}</h1>\n    <p>{{ 'Your requested resource could not be found' | translate}}</p>\n  </div>\n  ", styles: [""], dependencies: [{ kind: "pipe", type: i5$1.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: PageNotfoundComponent, decorators: [{
            type: Component,
            args: [{ selector: 'juice-page-notfound', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<div class=\"container pt-4\">\n    <h1>{{'Not found' | translate }}</h1>\n    <p>{{ 'Your requested resource could not be found' | translate}}</p>\n  </div>\n  " }]
        }] });

const routes = [];
class LayoutModule {
    static forRoot(production, options) {
        let config = new LayoutConfig(options);
        return {
            ngModule: LayoutModule,
            providers: [
                LayoutService,
                {
                    provide: IS_PRODUCTION,
                    useValue: production
                },
                {
                    provide: LayoutConfig,
                    useValue: config
                }
            ]
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LayoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.0.6", ngImport: i0, type: LayoutModule, declarations: [PageComponent,
            DarkModeComponent,
            NavMenuComponent,
            ExpandableMenuComponent,
            PageNotfoundComponent,
            SearchBarComponent,
            UserProfileComponent], imports: [i1$2.RouterModule, CommonModule,
            TranslatePipe,
            TranslateDirective,
            MatIconModule,
            MatToolbarModule,
            MatSidenavModule,
            MatButtonModule,
            MatExpansionModule,
            MatListModule,
            MatFormFieldModule,
            MatInputModule,
            MatTooltipModule], exports: [PageComponent,
            RouterModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LayoutModule, imports: [RouterModule.forChild(routes),
            CommonModule,
            MatIconModule,
            MatToolbarModule,
            MatSidenavModule,
            MatButtonModule,
            MatExpansionModule,
            MatListModule,
            MatFormFieldModule,
            MatInputModule,
            MatTooltipModule, RouterModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LayoutModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        PageComponent,
                        DarkModeComponent,
                        NavMenuComponent,
                        ExpandableMenuComponent,
                        PageNotfoundComponent,
                        SearchBarComponent,
                        UserProfileComponent,
                    ],
                    imports: [
                        RouterModule.forChild(routes),
                        CommonModule,
                        TranslatePipe,
                        TranslateDirective,
                        MatIconModule,
                        MatToolbarModule,
                        MatSidenavModule,
                        MatButtonModule,
                        MatExpansionModule,
                        MatListModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatTooltipModule
                    ],
                    exports: [
                        PageComponent,
                        RouterModule
                    ]
                }]
        }] });

/**
 * This module for study purpose only.
 * Consider using matTooltip from @angular/material
 */
class TooltipModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TooltipModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.0.6", ngImport: i0, type: TooltipModule, declarations: [TooltipComponent,
            TooltipDirective], imports: [CommonModule], exports: [TooltipDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TooltipModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TooltipModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        TooltipComponent,
                        TooltipDirective
                    ],
                    imports: [
                        CommonModule
                    ],
                    exports: [
                        TooltipDirective
                    ]
                }]
        }] });

class DevGuard {
    constructor() {
        this.isProduction = inject(IS_PRODUCTION);
    }
    canActivate() {
        console.log('DevGuard: this route is available in development environment only!', this.isProduction);
        return !this.isProduction;
    }
    canDisplay() {
        console.log('DevGuard: this menu is available in development environment only!', this.isProduction);
        return !this.isProduction;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: DevGuard, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: DevGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: DevGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class UserProfileDialogComponent {
    constructor(auth, cdr) {
        this.auth = auth;
        this.cdr = cdr;
        this.username = '';
        this.name = '';
        this.email = '';
        this.loggedin = false;
    }
    ngOnInit() {
        if (this.auth.hasValidIdToken()) {
            const claims = this.auth.getIdentityClaims();
            if (claims['preferred_username']) {
                this.setValues(claims);
            }
            else {
                this.auth.loadUserProfile().then(info => {
                    var userProfile = info;
                    if (userProfile) {
                        this.setValues(userProfile.info);
                        // Resolved outside an event: mark explicitly for zoneless apps.
                        this.cdr.markForCheck();
                    }
                    else {
                        console.debug('No user profile', info);
                    }
                });
            }
        }
    }
    setValues(claims) {
        this.username = claims['preferred_username'];
        this.name = claims['name'];
        this.email = claims['email'] ?? '';
        this.loggedin = true;
    }
    logout() {
        this.auth.loadDiscoveryDocument().then(() => {
            this.auth.logOut();
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserProfileDialogComponent, deps: [{ token: i3$1.OAuthService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: UserProfileDialogComponent, isStandalone: false, selector: "app-user-profile", ngImport: i0, template: "@if (loggedin) {\r\n  <h3 mat-dialog-title>{{name}}</h3>\r\n}\r\n<div mat-dialog-content>\r\n  @if (loggedin) {\r\n    <div>\r\n      @if (name) {\r\n        <p>{{'Welcome' | translate}} {{name}}</p>\r\n      }\r\n      @if (email) {\r\n        <p>{{ 'Email' | translate}}: {{email}}</p>\r\n      }\r\n      <!-- Logout -->\r\n    </div>\r\n  }\r\n  @if (!loggedin) {\r\n    <div>\r\n      <p>{{ 'Please login to view your profile' | translate}}</p>\r\n    </div>\r\n  }\r\n</div>\r\n<div mat-dialog-actions>\r\n  @if (loggedin) {\r\n    <button mat-raised-button color=\"primary\" (click)=\"logout()\">{{ 'Logout' | translate}}</button>\r\n  }\r\n  <button mat-button mat-dialog-close cdkFocusInitial>{{ 'Close' | translate}}</button>\r\n</div>", styles: [""], dependencies: [{ kind: "directive", type: i2.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i2.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i2.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i2.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "component", type: i3.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "pipe", type: i5$1.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserProfileDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-user-profile', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "@if (loggedin) {\r\n  <h3 mat-dialog-title>{{name}}</h3>\r\n}\r\n<div mat-dialog-content>\r\n  @if (loggedin) {\r\n    <div>\r\n      @if (name) {\r\n        <p>{{'Welcome' | translate}} {{name}}</p>\r\n      }\r\n      @if (email) {\r\n        <p>{{ 'Email' | translate}}: {{email}}</p>\r\n      }\r\n      <!-- Logout -->\r\n    </div>\r\n  }\r\n  @if (!loggedin) {\r\n    <div>\r\n      <p>{{ 'Please login to view your profile' | translate}}</p>\r\n    </div>\r\n  }\r\n</div>\r\n<div mat-dialog-actions>\r\n  @if (loggedin) {\r\n    <button mat-raised-button color=\"primary\" (click)=\"logout()\">{{ 'Logout' | translate}}</button>\r\n  }\r\n  <button mat-button mat-dialog-close cdkFocusInitial>{{ 'Close' | translate}}</button>\r\n</div>" }]
        }], ctorParameters: () => [{ type: i3$1.OAuthService }, { type: i0.ChangeDetectorRef }] });

class UserProfileDialogService extends ProfileDialogService {
    constructor(matDialog) {
        super(matDialog);
    }
    async open(data) {
        return this.matDialog.open(UserProfileDialogComponent, { position: { top: '50px', right: '10px' } });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserProfileDialogService, deps: [{ token: i2.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserProfileDialogService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserProfileDialogService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i2.MatDialog }] });

class UserProfileDialogModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserProfileDialogModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.0.6", ngImport: i0, type: UserProfileDialogModule, declarations: [UserProfileDialogComponent], imports: [MatDialogModule,
            MatButtonModule,
            TranslatePipe,
            TranslateDirective,
            CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserProfileDialogModule, providers: [
            {
                provide: ProfileDialogService,
                useClass: UserProfileDialogService
            }
        ], imports: [MatDialogModule,
            MatButtonModule,
            CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserProfileDialogModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        UserProfileDialogComponent
                    ],
                    imports: [
                        MatDialogModule,
                        MatButtonModule,
                        TranslatePipe,
                        TranslateDirective,
                        CommonModule
                    ],
                    exports: [],
                    providers: [
                        {
                            provide: ProfileDialogService,
                            useClass: UserProfileDialogService
                        }
                    ]
                }]
        }] });

/*
 * Public API Surface of layout
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DevGuard, ExpandableMenuComponent, LayoutModule, LayoutService, NavMenuComponent, PageComponent, PageNotfoundComponent, ProfileDialogService, SearchService, TooltipDirective, TooltipModule, TooltipPosition, UserProfileDialogModule, isSearchablePage };
//# sourceMappingURL=juice-js-layout.mjs.map
