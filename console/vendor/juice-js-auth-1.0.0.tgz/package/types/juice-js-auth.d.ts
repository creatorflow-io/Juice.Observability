import * as i0 from '@angular/core';
import { OnInit, ModuleWithProviders } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import * as i1 from '@angular/router';
import { ActivatedRoute, Router, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { HttpClient, HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import * as i7 from '@ngx-translate/core';
import * as i8 from '@angular/material/dialog';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import { TenantService } from '@juice-js/core';

declare class LoginComponent implements OnInit {
    private oauthService;
    private activatedRoute;
    constructor(oauthService: OAuthService, activatedRoute: ActivatedRoute);
    ngOnInit(): Promise<void>;
    login(returnUrl: string): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginComponent, "page-login", never, {}, {}, never, never, false, never>;
}

declare class LoginCompletedComponent implements OnInit {
    private router;
    private activatedRoute;
    private oauthService;
    constructor(router: Router, activatedRoute: ActivatedRoute, oauthService: OAuthService);
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginCompletedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginCompletedComponent, "page-login-completed", never, {}, {}, never, never, false, never>;
}

declare class LogoutComponent implements OnInit {
    private oauthService;
    constructor(oauthService: OAuthService);
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogoutComponent, "page-logout", never, {}, {}, never, never, false, never>;
}

declare class LogoutCompletedComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoutCompletedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogoutCompletedComponent, "page-logout-completed", never, {}, {}, never, never, false, never>;
}

declare class UnauthorizedComponent {
    message: string;
    constructor(activatedRoute: ActivatedRoute);
    static ɵfac: i0.ɵɵFactoryDeclaration<UnauthorizedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnauthorizedComponent, "page-unauthorized", never, {}, {}, never, never, false, never>;
}

declare class UserInfoComponent implements OnInit {
    private oauthService;
    private http;
    userInfo: string;
    accessToken: string;
    idToken: string;
    constructor(oauthService: OAuthService, http: HttpClient);
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserInfoComponent, "page-user-info", never, {}, {}, never, never, false, never>;
}

declare class AuthModule {
    static forRoot(options: any): ModuleWithProviders<AuthModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AuthModule, [typeof LoginComponent, typeof LoginCompletedComponent, typeof LogoutComponent, typeof LogoutCompletedComponent, typeof UnauthorizedComponent, typeof UserInfoComponent], [typeof i7.TranslatePipe, typeof i7.TranslateDirective, typeof i8.MatDialogModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AuthModule>;
}

declare class AuthModuleConfig {
    basePath: string;
    /**
     * Base URLs the AuthInterceptor sends the bearer token to; a request matches when its URL equals one of them or
     * continues it with `/` or `?`. An empty string matches relative URLs.
     *
     * Unset: the app's own origin only (relative URLs and `window.location.origin`), so the identity server, CDNs
     * and third-party APIs never see the token. List every API host the app calls with the token.
     *
     * `['*']` restores the pre-2.0 behaviour — the token on every request, whatever the host. A migration aid only:
     * it leaks the token to any host the app happens to call.
     */
    allowedUrls?: string[];
    /**
     * Renew the access token with the refresh token shortly before it expires (needs the `offline_access` scope).
     * Default false: an app that renews the token itself (e.g. `@hd/layout`'s `provideHdStation`) must not do it twice,
     * or a rotating refresh token is redeemed twice and the second request fails.
     */
    automaticRefresh?: boolean;
}

/**
 * Renews the access token with the refresh token. Concurrent callers — the interceptor's 401 retries, the guard and
 * the expiry timer — share one request, so a rotating refresh token is redeemed once.
 */
declare class AuthTokenRefresher {
    private oauthService;
    private refreshing?;
    constructor(oauthService: OAuthService);
    /** True when a refresh token is stored, so an expired session can be renewed without a login round-trip. */
    canRefresh(): boolean;
    /** Resolves true when a new access token was obtained; never rejects. */
    refresh(): Promise<boolean>;
    private doRefresh;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthTokenRefresher, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthTokenRefresher>;
}

declare class AuthGuard {
    private router;
    private oauthService;
    private options;
    private tenantService;
    private refresher;
    path: string;
    constructor(router: Router, oauthService: OAuthService, options: AuthModuleConfig, tenantService: TenantService, refresher: AuthTokenRefresher);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): true | UrlTree | rxjs.Observable<true | UrlTree>;
    /** Completes an OIDC callback if this is one; otherwise renews an expired session with the refresh token. */
    private restoreSession;
    /** The tenant and role checks, for a session found valid or just restored. */
    private authorize;
    private hasValidRole;
    private hasValidToken;
    private hasValidTenant;
    private getTenantFromIssuer;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthGuard, [null, null, null, { optional: true; }, null]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthGuard>;
}

/**
 * Adds `Authorization: Bearer …` to requests for {@link AuthModuleConfig.allowedUrls} (the app's own origin when that
 * is unset). With a refresh token stored, an expired token is renewed before the request, and a 401 renews it and
 * retries once.
 */
declare class AuthInterceptor implements HttpInterceptor {
    private auth;
    private options;
    private refresher;
    constructor(auth: OAuthService, options: AuthModuleConfig, refresher: AuthTokenRefresher);
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    private withToken;
    private isIdentityServer;
    private isAllowed;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthInterceptor>;
}

/**
 * Who is signed in, as a stable key (the `sub` claim), for anything that caches per user — menus, permissions,
 * profile data — and must start over when the user changes.
 *
 * A session whose access token expired but can still be refreshed counts as the same user, so a page reload or a
 * token renewal is not reported as a sign-in.
 *
 * ```ts
 * inject(AuthSession).changes.subscribe(() => this.cache.clear());
 * ```
 */
declare class AuthSession {
    private oauthService;
    private readonly key$;
    /** The current user key (`null` = nobody), then every change. */
    readonly user$: Observable<string | null>;
    /** Every change after the current value: sign-in (`null` → key), sign-out (key → `null`), another user. */
    readonly changes: Observable<string | null>;
    constructor(oauthService: OAuthService);
    /** The signed-in user's key now; `null` when nobody is. */
    get userKey(): string | null;
    private readKey;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthSession, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthSession>;
}

declare class AuthRoutingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthRoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AuthRoutingModule, never, [typeof i1.RouterModule], [typeof i1.RouterModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AuthRoutingModule>;
}

export { AuthGuard, AuthInterceptor, AuthModule, AuthModuleConfig, AuthRoutingModule, AuthSession, AuthTokenRefresher };
