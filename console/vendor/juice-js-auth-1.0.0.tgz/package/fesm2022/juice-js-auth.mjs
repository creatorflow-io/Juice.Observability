import * as i0 from '@angular/core';
import { ChangeDetectionStrategy, Component, Injectable, isDevMode, provideEnvironmentInitializer, NgModule, inject, Optional } from '@angular/core';
import * as i3 from '@ngx-translate/core';
import { TranslatePipe, TranslateDirective, provideChildTranslateService, MissingTranslationHandler } from '@ngx-translate/core';
import * as i1 from 'angular-oauth2-oidc';
import { AuthConfig, OAuthService } from 'angular-oauth2-oidc';
import * as i1$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import { filter, delay, switchMap, catchError, map, distinctUntilChanged, skip } from 'rxjs/operators';
import * as i2 from '@angular/common/http';
import { HttpErrorResponse, HTTP_INTERCEPTORS } from '@angular/common/http';
import { from, throwError, BehaviorSubject } from 'rxjs';
import { SubmitMissingTranslationHandler } from '@juice-js/localize';
import { MatDialogModule } from '@angular/material/dialog';
import * as i4 from '@juice-js/core';
import { TenantService } from '@juice-js/core';
import { DevGuard } from '@juice-js/layout';

class LoginComponent {
    constructor(oauthService, activatedRoute) {
        this.oauthService = oauthService;
        this.activatedRoute = activatedRoute;
    }
    async ngOnInit() {
        const returnUrl = this.activatedRoute.snapshot.queryParams["returnUrl"] ?? '/home';
        console.log('[Login] returnUrl', this.activatedRoute.snapshot.queryParams["returnUrl"]);
        await this.login(returnUrl);
    }
    async login(returnUrl) {
        await this.oauthService.loadDiscoveryDocument();
        this.oauthService.initLoginFlow(returnUrl);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LoginComponent, deps: [{ token: i1.OAuthService }, { token: i1$1.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.6", type: LoginComponent, isStandalone: false, selector: "page-login", ngImport: i0, template: "<div class=\"p-4 text-center\">\r\n  <p>{{'We are redirecting you to login page...' | translate }}</p>\r\n</div>\r\n", styles: [""], dependencies: [{ kind: "pipe", type: i3.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LoginComponent, decorators: [{
            type: Component,
            args: [{ selector: 'page-login', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<div class=\"p-4 text-center\">\r\n  <p>{{'We are redirecting you to login page...' | translate }}</p>\r\n</div>\r\n" }]
        }], ctorParameters: () => [{ type: i1.OAuthService }, { type: i1$1.ActivatedRoute }] });

class LoginCompletedComponent {
    constructor(router, activatedRoute, oauthService) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.oauthService = oauthService;
    }
    async ngOnInit() {
        this.oauthService.events.pipe(filter(e => e.type === "token_received"), delay(2000)).subscribe((e) => {
            // `this.oauthService.state` contains the redirect url after login, if any
            let redirectUrl = '';
            if (this.oauthService.state) {
                redirectUrl = appRelativeUrl(decodeURIComponent(decodeURIComponent(this.oauthService.state)));
            }
            this.router.navigateByUrl(redirectUrl);
        });
        await this.oauthService.loadDiscoveryDocumentAndTryLogin({ disableNonceCheck: true });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LoginCompletedComponent, deps: [{ token: i1$1.Router }, { token: i1$1.ActivatedRoute }, { token: i1.OAuthService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.6", type: LoginCompletedComponent, isStandalone: false, selector: "page-login-completed", ngImport: i0, template: "<div class=\"container p-4\">\r\n  <h1>{{'Login completed' | translate }}</h1>\r\n  <p>{{'Just to confirm that you did it right!' | translate}}</p>\r\n\r\n  <p>{{'We are now redirecting you to the requested page...' | translate}}</p>\r\n</div>\r\n", styles: [""], dependencies: [{ kind: "pipe", type: i3.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LoginCompletedComponent, decorators: [{
            type: Component,
            args: [{ selector: 'page-login-completed', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<div class=\"container p-4\">\r\n  <h1>{{'Login completed' | translate }}</h1>\r\n  <p>{{'Just to confirm that you did it right!' | translate}}</p>\r\n\r\n  <p>{{'We are now redirecting you to the requested page...' | translate}}</p>\r\n</div>\r\n" }]
        }], ctorParameters: () => [{ type: i1$1.Router }, { type: i1$1.ActivatedRoute }, { type: i1.OAuthService }] });
/**
 * The return URL when it is a path of this application (`/…`), otherwise `''` (the app root). The OAuth `state`
 * round-trips through the browser, so an absolute or protocol-relative URL (`https://…`, `//…`, `/\…`) is not
 * followed.
 */
function appRelativeUrl(url) {
    return url.startsWith('/') && !url.startsWith('//') && !url.startsWith('/\\') ? url : '';
}

class LogoutComponent {
    constructor(oauthService) {
        this.oauthService = oauthService;
    }
    async ngOnInit() {
        await this.oauthService.loadDiscoveryDocument();
        await this.oauthService.revokeTokenAndLogout();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LogoutComponent, deps: [{ token: i1.OAuthService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.6", type: LogoutComponent, isStandalone: false, selector: "page-logout", ngImport: i0, template: "<div class=\"pt-4 text-center\">\r\n  <p>{{'We are logging you out...'| translate}}</p>\r\n</div>\r\n", styles: [""], dependencies: [{ kind: "pipe", type: i3.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LogoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'page-logout', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<div class=\"pt-4 text-center\">\r\n  <p>{{'We are logging you out...'| translate}}</p>\r\n</div>\r\n" }]
        }], ctorParameters: () => [{ type: i1.OAuthService }] });

class LogoutCompletedComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LogoutCompletedComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.6", type: LogoutCompletedComponent, isStandalone: false, selector: "page-logout-completed", ngImport: i0, template: "<div class=\"container pt-4\">\r\n  <h1>{{'Logout' | translate}}</h1>\r\n  <p>{{'You successfully logged out from the application.' | translate}}</p>\r\n\r\n  <p>{{'If you want to access the application again,' | translate}} <a routerLink=\"../login\">{{'log in' | translate}}</a>.</p>\r\n</div>\r\n", styles: [""], dependencies: [{ kind: "pipe", type: i3.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LogoutCompletedComponent, decorators: [{
            type: Component,
            args: [{ selector: 'page-logout-completed', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<div class=\"container pt-4\">\r\n  <h1>{{'Logout' | translate}}</h1>\r\n  <p>{{'You successfully logged out from the application.' | translate}}</p>\r\n\r\n  <p>{{'If you want to access the application again,' | translate}} <a routerLink=\"../login\">{{'log in' | translate}}</a>.</p>\r\n</div>\r\n" }]
        }] });

const DEFAULT_MESSAGE = 'You are unauthorized to access this resource.';
const REASON_MESSAGES = {
    'tenant-mismatch': 'Your session belongs to a different tenant. Sign out, then sign in again to access this tenant.',
    'role-mismatch': 'You do not have the required role to access this resource.',
};
class UnauthorizedComponent {
    constructor(activatedRoute) {
        var reason = activatedRoute.snapshot.queryParams['reason'];
        this.message = REASON_MESSAGES[reason] ?? DEFAULT_MESSAGE;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UnauthorizedComponent, deps: [{ token: i1$1.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.6", type: UnauthorizedComponent, isStandalone: false, selector: "page-unauthorized", ngImport: i0, template: "<div class=\"container p-4\">\r\n    <h1>{{'Unauthorized' | translate }}</h1>\r\n    <p>{{ message | translate}}</p>\r\n  </div>\r\n  ", dependencies: [{ kind: "pipe", type: i3.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UnauthorizedComponent, decorators: [{
            type: Component,
            args: [{ selector: 'page-unauthorized', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<div class=\"container p-4\">\r\n    <h1>{{'Unauthorized' | translate }}</h1>\r\n    <p>{{ message | translate}}</p>\r\n  </div>\r\n  " }]
        }], ctorParameters: () => [{ type: i1$1.ActivatedRoute }] });

class UserInfoComponent {
    constructor(oauthService, http) {
        this.oauthService = oauthService;
        this.http = http;
        this.userInfo = '';
        this.accessToken = '';
        this.idToken = '';
    }
    async ngOnInit() {
        this.accessToken = this.oauthService.getAccessToken();
        this.idToken = this.oauthService.getIdToken();
        console.log(this.oauthService.getIdentityClaims());
        await this.oauthService.loadDiscoveryDocument();
        this.oauthService.loadUserProfile().then(info => {
            this.userInfo = JSON.stringify(info, null, 2);
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserInfoComponent, deps: [{ token: i1.OAuthService }, { token: i2.HttpClient }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.6", type: UserInfoComponent, isStandalone: false, selector: "page-user-info", ngImport: i0, template: "<h1>{{'User info' | translate}} </h1>\r\n<pre>{{userInfo}}</pre>\r\n\r\n<h5>{{'Access Token' | translate}}</h5>\r\n<pre>{{accessToken}}</pre>\r\n\r\n<h5>{{'ID Token' | translate}}</h5>\r\n<pre>{{idToken}}</pre>\r\n", styles: [""], dependencies: [{ kind: "pipe", type: i3.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UserInfoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'page-user-info', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<h1>{{'User info' | translate}} </h1>\r\n<pre>{{userInfo}}</pre>\r\n\r\n<h5>{{'Access Token' | translate}}</h5>\r\n<pre>{{accessToken}}</pre>\r\n\r\n<h5>{{'ID Token' | translate}}</h5>\r\n<pre>{{idToken}}</pre>\r\n" }]
        }], ctorParameters: () => [{ type: i1.OAuthService }, { type: i2.HttpClient }] });

class AuthModuleConfig {
    constructor() {
        this.basePath = "";
    }
}

/**
 * Renews the access token with the refresh token. Concurrent callers — the interceptor's 401 retries, the guard and
 * the expiry timer — share one request, so a rotating refresh token is redeemed once.
 */
class AuthTokenRefresher {
    constructor(oauthService) {
        this.oauthService = oauthService;
    }
    /** True when a refresh token is stored, so an expired session can be renewed without a login round-trip. */
    canRefresh() {
        return !!this.oauthService.getRefreshToken();
    }
    /** Resolves true when a new access token was obtained; never rejects. */
    refresh() {
        if (!this.canRefresh()) {
            return Promise.resolve(false);
        }
        this.refreshing ??= this.doRefresh().finally(() => (this.refreshing = undefined));
        return this.refreshing;
    }
    async doRefresh() {
        try {
            // The token endpoint comes from the discovery document, which a page outside AuthGuard may not have loaded.
            if (!this.oauthService.discoveryDocumentLoaded) {
                await this.oauthService.loadDiscoveryDocument();
            }
            await this.oauthService.refreshToken();
            return this.oauthService.hasValidAccessToken();
        }
        catch {
            return false;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthTokenRefresher, deps: [{ token: i1.OAuthService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthTokenRefresher, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthTokenRefresher, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.OAuthService }] });

let warnedUnrestricted = false;
/**
 * Adds `Authorization: Bearer …` to requests for {@link AuthModuleConfig.allowedUrls} (the app's own origin when that
 * is unset). With a refresh token stored, an expired token is renewed before the request, and a 401 renews it and
 * retries once.
 */
class AuthInterceptor {
    constructor(auth, options, refresher) {
        this.auth = auth;
        this.options = options;
        this.refresher = refresher;
    }
    intercept(req, next) {
        if (!this.isAllowed(req.url)) {
            return next.handle(req);
        }
        const send = () => next.handle(this.withToken(req));
        if (this.isIdentityServer(req.url)) {
            // The discovery and token requests the refresh itself makes: renewing here would wait on itself.
            return send();
        }
        const first$ = !this.auth.hasValidAccessToken() && this.refresher.canRefresh()
            ? from(this.refresher.refresh()).pipe(switchMap(send))
            : send();
        return first$.pipe(catchError((error) => {
            if (error instanceof HttpErrorResponse && error.status === 401 && this.refresher.canRefresh()) {
                return from(this.refresher.refresh()).pipe(switchMap((renewed) => renewed ? send() : throwError(() => error)));
            }
            return throwError(() => error);
        }));
    }
    withToken(req) {
        if (!this.auth.hasValidAccessToken()) {
            return req;
        }
        // Clone the request and replace the original headers with cloned headers, updated with the authorization.
        return req.clone({
            headers: req.headers.set('Authorization', `Bearer ${this.auth.getAccessToken()}`)
        });
    }
    isIdentityServer(url) {
        const urls = [this.auth.issuer, this.auth.tokenEndpoint].filter((u) => !!u);
        return urls.some((u) => matches(url, u));
    }
    isAllowed(url) {
        const allowed = this.options?.allowedUrls ?? ['', ownOrigin()];
        if (allowed.includes('*')) {
            if (isDevMode() && !warnedUnrestricted) {
                warnedUnrestricted = true;
                console.warn('[@juice-js/auth] AuthModuleConfig.allowedUrls is [\'*\']: the access token is sent with every '
                    + 'request, to any host. List the APIs that should receive it instead.');
            }
            return true;
        }
        return allowed.some((base) => matches(url, base));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthInterceptor, deps: [{ token: i1.OAuthService }, { token: AuthModuleConfig }, { token: AuthTokenRefresher }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthInterceptor }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.OAuthService }, { type: AuthModuleConfig }, { type: AuthTokenRefresher }] });
/** The default allow-list's absolute entry; empty outside a browser, which leaves relative URLs only. */
function ownOrigin() {
    return typeof window !== 'undefined' && window.location?.origin ? window.location.origin : '';
}
/** `url` is `base` or continues it with `/` or `?`; an empty base (the app's own origin) matches relative URLs only. */
function matches(url, base) {
    if (!base) {
        return !/^[a-z][a-z0-9+.-]*:\/\//i.test(url) && !url.startsWith('//');
    }
    const trimmed = base.replace(/\/+$/, '');
    return url === trimmed || url.startsWith(trimmed + '/') || url.startsWith(trimmed + '?');
}

class AuthModule {
    static forRoot(options) {
        const extra = options?.automaticRefresh
            ? [provideEnvironmentInitializer(renewBeforeExpiry)]
            : [];
        return {
            ngModule: AuthModule,
            providers: [
                ...extra,
                {
                    provide: HTTP_INTERCEPTORS,
                    useClass: AuthInterceptor,
                    multi: true
                },
                {
                    provide: AuthModuleConfig,
                    useValue: options
                },
                {
                    provide: AuthConfig,
                    useFactory: (tenantService) => {
                        // Create config from options
                        var authConfig = new AuthConfig(options);
                        // Replace :tenant with the current tenant
                        if (tenantService) {
                            let identifier = '/' + tenantService.currentTenant?.identifier || '';
                            authConfig.issuer = options.issuer?.replace('/:tenant', identifier);
                            authConfig.redirectUri = options.redirectUri?.replace('/:tenant', identifier);
                            authConfig.postLogoutRedirectUri = options.postLogoutRedirectUri?.replace('/:tenant', identifier);
                        }
                        return authConfig;
                    },
                    deps: [TenantService]
                }
            ]
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.0.6", ngImport: i0, type: AuthModule, declarations: [LoginComponent,
            LoginCompletedComponent,
            LogoutComponent,
            LogoutCompletedComponent,
            UnauthorizedComponent,
            UserInfoComponent], imports: [TranslatePipe,
            TranslateDirective,
            MatDialogModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthModule, providers: [
            provideChildTranslateService({
                missingTranslationHandler: {
                    provide: MissingTranslationHandler,
                    useClass: SubmitMissingTranslationHandler
                }
            })
        ], imports: [MatDialogModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        LoginComponent,
                        LoginCompletedComponent,
                        LogoutComponent,
                        LogoutCompletedComponent,
                        UnauthorizedComponent,
                        UserInfoComponent
                    ],
                    imports: [
                        TranslatePipe,
                        TranslateDirective,
                        MatDialogModule
                    ],
                    exports: [],
                    providers: [
                        provideChildTranslateService({
                            missingTranslationHandler: {
                                provide: MissingTranslationHandler,
                                useClass: SubmitMissingTranslationHandler
                            }
                        })
                    ]
                }]
        }] });
/**
 * `AuthModuleConfig.automaticRefresh`: OAuthService fires `token_expires` at its timeoutFactor (75% of the lifetime
 * by default); renew the access token then, through the shared AuthTokenRefresher.
 */
function renewBeforeExpiry() {
    const oauthService = inject(OAuthService);
    const refresher = inject(AuthTokenRefresher);
    oauthService.events
        .pipe(filter((e) => e.type === 'token_expires' && e.info === 'access_token'))
        .subscribe(() => void refresher.refresh());
}

class AuthGuard {
    constructor(router, oauthService, options, tenantService, refresher) {
        this.router = router;
        this.oauthService = oauthService;
        this.options = options;
        this.tenantService = tenantService;
        this.refresher = refresher;
        this.path = new URL(this.options.basePath).pathname;
        if (tenantService) {
            var identifier = '/' + tenantService.currentTenant?.identifier || '';
            this.path = this.path.replace('/:tenant', identifier);
        }
    }
    canActivate(route, state) {
        if (this.hasValidToken()) {
            return this.authorize(route);
        }
        return from(this.restoreSession()).pipe(map(() => {
            if (this.hasValidToken()) {
                return this.authorize(route);
            }
            return this.router.createUrlTree([`${this.path}/login`], { queryParams: { returnUrl: state.url } });
        }));
    }
    /** Completes an OIDC callback if this is one; otherwise renews an expired session with the refresh token. */
    async restoreSession() {
        await this.oauthService.loadDiscoveryDocumentAndTryLogin({ disableNonceCheck: true });
        if (!this.hasValidToken() && this.refresher.canRefresh()) {
            await this.refresher.refresh();
        }
    }
    /** The tenant and role checks, for a session found valid or just restored. */
    authorize(route) {
        if (!this.hasValidTenant()) {
            // Re-authenticating cannot fix a tenant mismatch: the IdP would hand back the
            // same issuer and the /login redirect would bounce straight back here.
            return this.router.createUrlTree([`${this.path}/unauthorized`], { queryParams: { reason: 'tenant-mismatch' } });
        }
        if (this.hasValidRole(route)) {
            return true;
        }
        return this.router.createUrlTree([`${this.path}/unauthorized`], { queryParams: { reason: 'role-mismatch' } });
    }
    hasValidRole(route) {
        const claims = this.oauthService.getIdentityClaims();
        var { roles } = route.data;
        var { role } = claims;
        if (roles
            && ((typeof role == "string" && !roles.includes(role))
                || (Array.isArray(role) && !role.some(r => roles.includes(r))))) {
            return false;
        }
        return true;
    }
    hasValidToken() {
        return this.oauthService.hasValidAccessToken() && this.oauthService.hasValidIdToken();
    }
    hasValidTenant() {
        if (!this.tenantService) {
            return true;
        }
        const claims = this.oauthService.getIdentityClaims();
        var tenant = this.tenantService?.currentTenant?.identifier;
        var issuer = claims['iss'];
        return !tenant || this.getTenantFromIssuer(issuer) === tenant;
    }
    getTenantFromIssuer(issuer) {
        var match = issuer.match(/\/([^\/]+)\/?$/);
        return match?.[1];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthGuard, deps: [{ token: i1$1.Router }, { token: i1.OAuthService }, { token: AuthModuleConfig }, { token: i4.TenantService, optional: true }, { token: AuthTokenRefresher }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$1.Router }, { type: i1.OAuthService }, { type: AuthModuleConfig }, { type: i4.TenantService, decorators: [{
                    type: Optional
                }] }, { type: AuthTokenRefresher }] });

/** The OAuth events after which the signed-in user may be someone else, or nobody. */
const USER_EVENTS = [
    'token_received', 'token_refreshed', 'token_refresh_error', 'logout', 'session_terminated', 'session_error',
];
/**
 * Who is signed in, as a stable key (the `sub` claim), for anything that caches per user — menus, permissions,
 * profile data — and must start over when the user changes.
 *
 * A session whose access token expired but can still be refreshed counts as the same user, so a page reload or a
 * token renewal is not reported as a sign-in.
 *
 * ```ts
 * inject(AuthSession).changes.subscribe(() => this.cache.clear());
 * ```
 */
class AuthSession {
    constructor(oauthService) {
        this.oauthService = oauthService;
        this.key$ = new BehaviorSubject(this.readKey());
        this.user$ = this.key$.pipe(distinctUntilChanged());
        this.changes = this.user$.pipe(skip(1));
        this.oauthService.events
            .pipe(filter((e) => USER_EVENTS.includes(e.type)))
            .subscribe(() => this.key$.next(this.readKey()));
    }
    /** The signed-in user's key now; `null` when nobody is. */
    get userKey() {
        return this.key$.value;
    }
    readKey() {
        if (!this.oauthService.hasValidAccessToken() && !this.oauthService.getRefreshToken()) {
            return null;
        }
        const claims = this.oauthService.getIdentityClaims();
        const sub = claims?.['sub'] ?? subOf(this.oauthService.getAccessToken());
        return typeof sub === 'string' && sub ? sub : null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthSession, deps: [{ token: i1.OAuthService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthSession, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthSession, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.OAuthService }] });
/** The `sub` of a JWT access token, unverified (a key only; the APIs verify the token). */
function subOf(token) {
    const payload = token?.split('.')[1];
    if (!payload) {
        return undefined;
    }
    try {
        return JSON.parse(atob(payload.replace(/-/g, '+').replace(/_/g, '/')))['sub'];
    }
    catch {
        return undefined;
    }
}

const routes = [
    { path: 'login', component: LoginComponent, title: 'Login' },
    { path: 'login-completed', component: LoginCompletedComponent, title: 'Login completed' },
    { path: 'logout', component: LogoutComponent },
    { path: 'logout-completed', component: LogoutCompletedComponent, title: 'Logout completed' },
    { path: 'unauthorized', component: UnauthorizedComponent, title: 'Unauthorized' },
    { path: 'user-info', component: UserInfoComponent, canActivate: [AuthGuard, DevGuard], title: 'User info',
        data: {
            menuDisplay: [DevGuard],
            menuIcon: 'account_circle',
            menuOrder: 100,
        } },
    { path: '', redirectTo: 'user-info', pathMatch: 'full' },
];
class AuthRoutingModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthRoutingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.0.6", ngImport: i0, type: AuthRoutingModule, imports: [i1$1.RouterModule], exports: [RouterModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthRoutingModule, imports: [RouterModule.forChild(routes), RouterModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: AuthRoutingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [RouterModule.forChild(routes)],
                    exports: [RouterModule],
                }]
        }] });

/*
 * Public API Surface of auth
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AuthGuard, AuthInterceptor, AuthModule, AuthModuleConfig, AuthRoutingModule, AuthSession, AuthTokenRefresher };
//# sourceMappingURL=juice-js-auth.mjs.map
