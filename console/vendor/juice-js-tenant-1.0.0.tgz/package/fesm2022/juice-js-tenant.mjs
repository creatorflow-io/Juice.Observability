import * as i0 from '@angular/core';
import { ChangeDetectionStrategy, Component, NgModule, Injectable } from '@angular/core';
import * as i1$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i1 from '@ngx-translate/core';
import { TranslatePipe, TranslateDirective } from '@ngx-translate/core';
import { PageComponent } from '@juice-js/layout';
import * as i2 from '@juice-js/core';

class TenantMismatchComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantMismatchComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.6", type: TenantMismatchComponent, isStandalone: false, selector: "page-tenant-mismatch", ngImport: i0, template: "<div class=\"container pt-4\">\n    <h1>{{'Unauthorized' | translate }}</h1>\n    <p>{{ 'Your requested tenant does not match.' | translate}}</p>\n  </div>\n  ", dependencies: [{ kind: "pipe", type: i1.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantMismatchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'page-tenant-mismatch', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<div class=\"container pt-4\">\n    <h1>{{'Unauthorized' | translate }}</h1>\n    <p>{{ 'Your requested tenant does not match.' | translate}}</p>\n  </div>\n  " }]
        }] });

const routes = [
    {
        path: ':tenant/tenant-mismatch',
        component: PageComponent,
        children: [
            { path: '', component: TenantMismatchComponent }
        ]
    },
    {
        path: 'tenant-mismatch',
        component: PageComponent,
        children: [
            { path: '', component: TenantMismatchComponent }
        ]
    }
];
class TenantRoutingModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantRoutingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.0.6", ngImport: i0, type: TenantRoutingModule, imports: [i1$1.RouterModule], exports: [RouterModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantRoutingModule, imports: [RouterModule.forChild(routes), RouterModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantRoutingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [RouterModule.forChild(routes)],
                    exports: [RouterModule],
                }]
        }] });

class TenantAuthModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantAuthModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.0.6", ngImport: i0, type: TenantAuthModule, declarations: [TenantMismatchComponent], imports: [TenantRoutingModule,
            TranslatePipe,
            TranslateDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantAuthModule, imports: [TenantRoutingModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantAuthModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        TenantMismatchComponent
                    ],
                    imports: [
                        TenantRoutingModule,
                        TranslatePipe,
                        TranslateDirective
                    ],
                    exports: []
                }]
        }] });

// This guard is used to check if the tenant is set and redirect to the tenant-mismatch page if not
class TenantGuard {
    constructor(router, tenantService) {
        this.router = router;
        this.tenantService = tenantService;
    }
    async canActivate(route, state) {
        var tenant = await this.tenantService.getTenantIdentifier();
        if (tenant && this.tenantService.isMatched()) {
            return true;
        }
        // check if the request is for the tenant-mismatch page
        console.debug(`Tenant mismatch`, this.router.url, this.tenantService.requestTenantIdentifier);
        if (this.tenantService.requestTenantIdentifier) {
            return this.router.createUrlTree([`/${this.tenantService.requestTenantIdentifier}/tenant-mismatch`]);
        }
        return this.router.createUrlTree([`/tenant-mismatch`]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantGuard, deps: [{ token: i1$1.Router }, { token: i2.TenantService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: TenantGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$1.Router }, { type: i2.TenantService }] });

/*
 * Public API Surface of tenant
 */

/**
 * Generated bundle index. Do not edit.
 */

export { TenantAuthModule, TenantGuard };
//# sourceMappingURL=juice-js-tenant.mjs.map
