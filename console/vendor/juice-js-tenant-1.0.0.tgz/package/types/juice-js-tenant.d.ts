import * as i0 from '@angular/core';
import * as i1 from '@angular/router';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import * as i3 from '@ngx-translate/core';
import { TenantService } from '@juice-js/core';

declare class TenantMismatchComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<TenantMismatchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TenantMismatchComponent, "page-tenant-mismatch", never, {}, {}, never, never, false, never>;
}

declare class TenantRoutingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TenantRoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TenantRoutingModule, never, [typeof i1.RouterModule], [typeof i1.RouterModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TenantRoutingModule>;
}

declare class TenantAuthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TenantAuthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TenantAuthModule, [typeof TenantMismatchComponent], [typeof TenantRoutingModule, typeof i3.TranslatePipe, typeof i3.TranslateDirective], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TenantAuthModule>;
}

declare class TenantGuard {
    private router;
    private tenantService;
    constructor(router: Router, tenantService: TenantService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<true | i1.UrlTree>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TenantGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TenantGuard>;
}

export { TenantAuthModule, TenantGuard };
