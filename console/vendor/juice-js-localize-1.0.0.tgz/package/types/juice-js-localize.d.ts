import { TranslateService, MissingTranslationHandler, MissingTranslationHandlerParams, TranslateLoader, TranslationObject } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { ModuleWithProviders } from '@angular/core';
import { Router } from '@angular/router';
import * as i2 from '@angular/material/select';
import * as i3 from '@angular/material/core';
import * as i4 from '@angular/common';
import * as i5 from '@angular/forms';

declare class LocalizeConfig {
    submitMissing: boolean;
    appName: string;
    localizeApi: string;
    cultureApi: string;
}
interface ILocalizeConfig {
    submitMissing?: boolean;
    appName?: string;
    localizeApi: string;
    cultureApi: string;
}

interface CultureInfo {
    key: string;
    displayName: string;
}
declare class LocalizeService {
    private http;
    private options;
    constructor(http: HttpClient, options: LocalizeConfig);
    fetchCultures(): Observable<CultureInfo[]>;
    fetch(lang: string, page: string): Observable<Object>;
    submit(page: string, appName: string, data: any): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LocalizeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LocalizeService>;
}

declare class UrlHelper {
    private router;
    url: string;
    page: string;
    constructor(router: Router);
    getCurrentUrl(): string;
    trimSlash(url: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UrlHelper, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UrlHelper>;
}

declare class CultureComponent {
    private translate;
    private localize;
    private router;
    private urlHelper;
    Cultures: CultureInfo[];
    culture: string;
    constructor(translate: TranslateService, localize: LocalizeService, router: Router, urlHelper: UrlHelper);
    loadTranslation(): void;
    changeCulture(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CultureComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CultureComponent, "juice-culture-select", never, {}, {}, never, never, false, never>;
}

declare class LocalizeModule {
    static forRoot(config: ILocalizeConfig): ModuleWithProviders<LocalizeModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LocalizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LocalizeModule, [typeof CultureComponent], [typeof i2.MatSelectModule, typeof i3.MatOptionModule, typeof i4.CommonModule, typeof i5.FormsModule], [typeof CultureComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LocalizeModule>;
}

declare class SubmitMissingTranslationHandler implements MissingTranslationHandler {
    private service;
    private options;
    private urlHeper;
    keys: Array<string>;
    lastUpdate: Date;
    constructor(service: LocalizeService, options: LocalizeConfig, urlHeper: UrlHelper);
    handle(params: MissingTranslationHandlerParams): string;
    checkForSubmit(): void;
    submit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubmitMissingTranslationHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubmitMissingTranslationHandler>;
}

declare class ScopedTranslateApiLoader implements TranslateLoader {
    private service;
    private urlHelper;
    constructor(service: LocalizeService, urlHelper: UrlHelper);
    /**
     * Gets the translations from the server
     */
    getTranslation(lang: string): Observable<TranslationObject>;
}

export { CultureComponent, LocalizeConfig, LocalizeModule, ScopedTranslateApiLoader, SubmitMissingTranslationHandler };
export type { ILocalizeConfig };
