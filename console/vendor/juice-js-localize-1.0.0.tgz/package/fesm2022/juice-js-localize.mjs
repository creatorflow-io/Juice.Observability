import * as i0 from '@angular/core';
import { Injectable, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i1$2 from '@ngx-translate/core';
import { Observable, timer } from 'rxjs';
import * as i1 from '@angular/common/http';
import { provideHttpClient, withXhr, withInterceptorsFromDi } from '@angular/common/http';
import * as i1$1 from '@angular/router';
import * as i5 from '@angular/material/select';
import { MatSelectModule } from '@angular/material/select';
import * as i6 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatOptionModule } from '@angular/material/core';

class LocalizeConfig {
    constructor() {
        this.submitMissing = false;
        this.appName = ''; // used for submit missing translation
        this.localizeApi = '';
        this.cultureApi = '';
    }
}

class LocalizeService {
    constructor(http, options) {
        this.http = http;
        this.options = options;
    }
    fetchCultures() {
        if (!this.options.cultureApi)
            return new Observable(function subscribe(observer) { });
        return this.http.get(this.options.cultureApi);
    }
    fetch(lang, page) {
        if (!this.options.localizeApi)
            return new Observable(function subscribe(observer) { });
        let scope = page.replace(/\//g, '.');
        var apiUrl = `${this.options.localizeApi}/${lang}/${scope}`;
        return this.http.get(apiUrl);
    }
    submit(page, appName, data) {
        if (this.options.submitMissing == false || !this.options.localizeApi) {
            return new Observable(function subscribe(observer) {
                observer.next(data);
                observer.complete();
            });
        }
        let scope = page.replace(/\//g, '.');
        var apiUrl = `${this.options.localizeApi}/${scope}/${appName}`;
        return this.http.post(apiUrl, data);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LocalizeService, deps: [{ token: i1.HttpClient }, { token: LocalizeConfig }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LocalizeService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LocalizeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: LocalizeConfig }] });

class UrlHelper {
    constructor(router) {
        this.router = router;
        this.url = this.getCurrentUrl();
        this.page = this.trimSlash(this.url.split('?')[0]);
        this.router.events.subscribe((event) => {
            this.url = this.getCurrentUrl();
            this.page = this.trimSlash(this.url.split('?')[0]);
        });
    }
    getCurrentUrl() {
        // Router.url can be undefined before the first navigation (Angular v20+);
        // coalesce to an empty string so downstream string ops stay safe.
        return this.router.url ?? '';
    }
    trimSlash(url) {
        if (url.startsWith('/')) {
            url = url.substring(1);
        }
        if (url.endsWith('/')) {
            url = url.substring(0, url.length - 1);
        }
        return url;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UrlHelper, deps: [{ token: i1$1.Router }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UrlHelper, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: UrlHelper, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$1.Router }] });

class CultureComponent {
    constructor(translate, localize, router, urlHelper) {
        this.translate = translate;
        this.localize = localize;
        this.router = router;
        this.urlHelper = urlHelper;
        this.Cultures = [];
        this.localize.fetchCultures().subscribe(cultures => {
            this.Cultures = cultures;
        });
        let storedCulture = localStorage.getItem('culture');
        console.debug("stored culture", storedCulture);
        this.culture = storedCulture ? storedCulture : (this.translate.getFallbackLang() ?? '');
        if (this.culture != this.translate.getCurrentLang()) {
            localStorage.setItem('culture', this.culture);
        }
        this.router.events.subscribe((event) => {
            if (event.constructor.name == "NavigationEnd") {
                this.loadTranslation();
            }
        });
    }
    loadTranslation() {
        this.translate.use(this.culture);
        if (this.culture != this.translate.getFallbackLang()) {
            console.debug("loading Translation", this.culture, this.urlHelper.page);
            this.localize.fetch(this.culture, this.urlHelper.page).subscribe((data) => {
                console.debug("loaded Translation", data);
                this.translate.setTranslation(this.culture, data);
            });
        }
    }
    changeCulture() {
        localStorage.setItem('culture', this.culture);
        this.loadTranslation();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: CultureComponent, deps: [{ token: i1$2.TranslateService }, { token: LocalizeService }, { token: i1$1.Router }, { token: UrlHelper }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: CultureComponent, isStandalone: false, selector: "juice-culture-select", ngImport: i0, template: "<mat-select [style.width.px]=\"180\" [style.margin-left.px]=\"40\" [(ngModel)]=\"culture\" (ngModelChange)=\"changeCulture()\">\r\n  @for (culture of Cultures; track culture) {\r\n    <mat-option [value]=\"culture.key\">\r\n      {{culture.displayName}}\r\n    </mat-option>\r\n  }\r\n</mat-select>", dependencies: [{ kind: "component", type: i5.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i5.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i6.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i6.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.Eager }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: CultureComponent, decorators: [{
            type: Component,
            args: [{ selector: 'juice-culture-select', changeDetection: ChangeDetectionStrategy.Eager, standalone: false, template: "<mat-select [style.width.px]=\"180\" [style.margin-left.px]=\"40\" [(ngModel)]=\"culture\" (ngModelChange)=\"changeCulture()\">\r\n  @for (culture of Cultures; track culture) {\r\n    <mat-option [value]=\"culture.key\">\r\n      {{culture.displayName}}\r\n    </mat-option>\r\n  }\r\n</mat-select>" }]
        }], ctorParameters: () => [{ type: i1$2.TranslateService }, { type: LocalizeService }, { type: i1$1.Router }, { type: UrlHelper }] });

class LocalizeModule {
    static forRoot(config) {
        return {
            ngModule: LocalizeModule,
            providers: [
                LocalizeService,
                {
                    provide: LocalizeConfig,
                    useValue: config
                }
            ]
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LocalizeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.0.6", ngImport: i0, type: LocalizeModule, declarations: [CultureComponent], imports: [MatSelectModule,
            MatOptionModule,
            CommonModule,
            FormsModule], exports: [CultureComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LocalizeModule, providers: [provideHttpClient(withXhr(), withInterceptorsFromDi())], imports: [MatSelectModule,
            MatOptionModule,
            CommonModule,
            FormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: LocalizeModule, decorators: [{
            type: NgModule,
            args: [{ declarations: [
                        CultureComponent,
                    ],
                    exports: [
                        CultureComponent
                    ], imports: [MatSelectModule,
                        MatOptionModule,
                        CommonModule,
                        FormsModule], providers: [provideHttpClient(withXhr(), withInterceptorsFromDi())] }]
        }] });

class SubmitMissingTranslationHandler {
    constructor(service, options, urlHeper) {
        this.service = service;
        this.options = options;
        this.urlHeper = urlHeper;
        this.keys = [];
        this.lastUpdate = new Date();
    }
    handle(params) {
        if (this.keys.indexOf(params.key) < 0 && params.translateService.getCurrentLang() != null
            && params.translateService.getCurrentLang() != params.translateService.getFallbackLang()) {
            console.debug("missing translation", params.translateService.getCurrentLang(), params.key);
            this.keys.push(params.key);
            timer(500).subscribe(() => this.checkForSubmit());
        }
        return params.key;
    }
    checkForSubmit() {
        if (!this.lastUpdate || new Date().getTime() - this.lastUpdate.getTime() > 500) {
            this.lastUpdate = new Date();
            this.submit();
        }
    }
    submit() {
        if (this.keys.length > 0) {
            let keys = this.keys;
            this.keys = [];
            var appName = this.options.appName;
            var page = this.urlHeper.page;
            this.service.submit(page, appName, keys)
                .subscribe({
                next: (data) => {
                    console.debug("submited missing translation", data);
                },
                error: (error) => {
                    if (error.error && error.error == "Not supported by server configuration") {
                        console.debug(error.error);
                    }
                    else {
                        console.error("error submiting missing translation", error);
                    }
                }
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SubmitMissingTranslationHandler, deps: [{ token: LocalizeService }, { token: LocalizeConfig }, { token: UrlHelper }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SubmitMissingTranslationHandler }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SubmitMissingTranslationHandler, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: LocalizeService }, { type: LocalizeConfig }, { type: UrlHelper }] });

class ScopedTranslateApiLoader {
    constructor(service, urlHelper) {
        this.service = service;
        this.urlHelper = urlHelper;
    }
    /**
     * Gets the translations from the server
     */
    getTranslation(lang) {
        console.log("loading translation", lang, this.urlHelper.page);
        return this.service.fetch(lang, this.urlHelper.page);
    }
}

/*
 * Public API Surface of localize
 */
// export * from './lib/localize.service';
// export * from './lib/url-helper';

/**
 * Generated bundle index. Do not edit.
 */

export { CultureComponent, LocalizeConfig, LocalizeModule, ScopedTranslateApiLoader, SubmitMissingTranslationHandler };
//# sourceMappingURL=juice-js-localize.mjs.map
